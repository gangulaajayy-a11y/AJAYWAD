import React, { useState } from 'react';
import { ArrowRight, CheckCircle2, Droplets } from 'lucide-react';
import type { ActivityLevel, GenderOption, TeamSquad } from '../types/hydration';
import { calculateDailyTarget } from '../utils/hydrationMath';
import { BrandLockup } from './Logo';

interface OnboardingPageProps {
  initialName: string;
  initialEmail: string;
  teams: TeamSquad[];
  onCompleteOnboarding: (payload: {
    name: string;
    email: string;
    age: number;
    weightKg: number;
    gender: GenderOption;
    activityLevel: ActivityLevel;
    teamAction:
      | { type: 'join'; teamId: string }
      | { type: 'create'; squadName: string };
  }) => void;
}

export const OnboardingPage: React.FC<OnboardingPageProps> = ({
  initialName,
  initialEmail,
  teams,
  onCompleteOnboarding,
}) => {
  const [name, setName] = useState(initialName || '');
  const [email, setEmail] = useState(initialEmail || '');
  const [password, setPassword] = useState('sipstreak2026');
  const [age, setAge] = useState('21');
  const [weightKg, setWeightKg] = useState('70');
  const [gender, setGender] = useState<GenderOption>('prefer-not-to-say');
  const [activityLevel, setActivityLevel] = useState<ActivityLevel>('moderate');
  const [teamMode, setTeamMode] = useState<'join' | 'create'>('join');
  const [selectedTeamId, setSelectedTeamId] = useState(teams[2]?.id ?? teams[0]?.id ?? '');
  const [newSquadName, setNewSquadName] = useState('');
  const [inviteLookup, setInviteLookup] = useState('');
  const [error, setError] = useState('');

  const parsedWeight = Number(weightKg);
  const calculatedTargetMl = calculateDailyTarget(
    Number.isFinite(parsedWeight) && parsedWeight > 0 ? parsedWeight : 70,
  );

  const handleInviteApply = () => {
    const code = inviteLookup.trim().toUpperCase();
    const match = teams.find((t) => t.inviteCode.toUpperCase() === code);
    if (match) {
      setSelectedTeamId(match.id);
      setError('');
    } else {
      setError('No squad matched that invite code. Try AQUA26, HOMIE7, BLKA04, or BLKB08.');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!name.trim()) {
      setError('Please enter your full name.');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setError('Please provide a valid email address.');
      return;
    }
    const ageNum = Number(age);
    if (!Number.isFinite(ageNum) || ageNum < 12 || ageNum > 100) {
      setError('Please enter an age between 12 and 100.');
      return;
    }
    if (!Number.isFinite(parsedWeight) || parsedWeight < 30 || parsedWeight > 220) {
      setError('Please enter a body weight between 30 kg and 220 kg.');
      return;
    }
    if (teamMode === 'create' && newSquadName.trim().length < 3) {
      setError('Squad name must be at least 3 characters.');
      return;
    }

    onCompleteOnboarding({
      name: name.trim(),
      email: email.trim(),
      age: Math.round(ageNum),
      weightKg: Math.round(parsedWeight),
      gender,
      activityLevel,
      teamAction:
        teamMode === 'create'
          ? { type: 'create', squadName: newSquadName.trim() }
          : { type: 'join', teamId: selectedTeamId },
    });
  };

  return (
    <div className="min-h-screen bg-[#f4f9ff] dark:bg-[#070e1d] text-slate-900 dark:text-slate-100 py-10 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8 flex items-center justify-between">
          <BrandLockup showSubtitle />
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Step 1 of 1 · Hydration Calibration
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Form */}
          <form
            onSubmit={handleSubmit}
            className="lg:col-span-8 rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800 p-7 space-y-5"
            noValidate
          >
            <div>
              <h1 className="font-display font-bold text-2xl text-slate-900 dark:text-white">
                Calibrate Your Hydration Profile
              </h1>
              <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
                We use your body weight to set your daily baseline water target and match you with a squad.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="ob-name" className="block text-sm font-medium mb-1.5">
                  Full Name
                </label>
                <input
                  id="ob-name"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Aarav Mehta"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              <div>
                <label htmlFor="ob-email" className="block text-sm font-medium mb-1.5">
                  Email
                </label>
                <input
                  id="ob-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="aarav@campus.edu"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              <div>
                <label htmlFor="ob-password" className="block text-sm font-medium mb-1.5">
                  Password
                </label>
                <input
                  id="ob-password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              <div>
                <label htmlFor="ob-age" className="block text-sm font-medium mb-1.5">
                  Age
                </label>
                <input
                  id="ob-age"
                  type="number"
                  min={12}
                  max={100}
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-sm font-mono-tabular focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              <div>
                <label htmlFor="ob-weight" className="block text-sm font-medium mb-1.5">
                  Body Weight (kg)
                </label>
                <input
                  id="ob-weight"
                  type="number"
                  min={30}
                  max={220}
                  value={weightKg}
                  onChange={(e) => setWeightKg(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-sm font-mono-tabular focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              <div>
                <label htmlFor="ob-gender" className="block text-sm font-medium mb-1.5">
                  Gender (optional)
                </label>
                <select
                  id="ob-gender"
                  value={gender}
                  onChange={(e) => setGender(e.target.value as GenderOption)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
                >
                  <option value="prefer-not-to-say">Prefer not to say</option>
                  <option value="female">Female</option>
                  <option value="male">Male</option>
                  <option value="non-binary">Non-binary</option>
                </select>
              </div>
            </div>

            <div>
              <label htmlFor="ob-activity" className="block text-sm font-medium mb-1.5">
                Daily Activity Level
              </label>
              <select
                id="ob-activity"
                value={activityLevel}
                onChange={(e) => setActivityLevel(e.target.value as ActivityLevel)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
              >
                <option value="sedentary">Sedentary (Desk / Library study)</option>
                <option value="moderate">Moderate (Daily campus walking)</option>
                <option value="active">Active (Gym / Intramural sports)</option>
                <option value="athlete">Athlete (High-volume training)</option>
              </select>
            </div>

            {/* Squad Choice */}
            <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold text-slate-900 dark:text-white">
                  Squad Assignment
                </span>
                <div className="flex gap-1 p-1 rounded-lg bg-slate-100 dark:bg-slate-900">
                  <button
                    type="button"
                    onClick={() => setTeamMode('join')}
                    className={`px-3 py-1 text-xs font-semibold rounded-md ${
                      teamMode === 'join'
                        ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
                        : 'text-slate-500 dark:text-slate-400'
                    }`}
                  >
                    Join Existing Squad
                  </button>
                  <button
                    type="button"
                    onClick={() => setTeamMode('create')}
                    className={`px-3 py-1 text-xs font-semibold rounded-md ${
                      teamMode === 'create'
                        ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
                        : 'text-slate-500 dark:text-slate-400'
                    }`}
                  >
                    Create New Squad
                  </button>
                </div>
              </div>

              {teamMode === 'join' ? (
                <div className="space-y-3">
                  <div>
                    <label htmlFor="ob-team-select" className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5">
                      Choose a Squad
                    </label>
                    <select
                      id="ob-team-select"
                      value={selectedTeamId}
                      onChange={(e) => setSelectedTeamId(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
                    >
                      {teams.map((t) => (
                        <option key={t.id} value={t.id}>
                          {t.name} ({t.members.length}/{t.maxMembers} members · Code: {t.inviteCode})
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={inviteLookup}
                      onChange={(e) => setInviteLookup(e.target.value)}
                      placeholder="Or enter invite code (e.g. AQUA26)"
                      aria-label="Enter invite code"
                      className="flex-1 px-3.5 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
                    />
                    <button
                      type="button"
                      onClick={handleInviteApply}
                      className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-semibold whitespace-nowrap shrink-0"
                    >
                      Apply Code
                    </button>
                  </div>
                </div>
              ) : (
                <div>
                  <label htmlFor="ob-new-squad" className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5">
                    New Squad Name (4–8 member league)
                  </label>
                  <input
                    id="ob-new-squad"
                    type="text"
                    value={newSquadName}
                    onChange={(e) => setNewSquadName(e.target.value)}
                    placeholder="e.g. Lab 4 Hydrators"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
                  />
                </div>
              )}
            </div>

            {error && (
              <div role="alert" className="text-xs font-medium text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 rounded-xl px-3.5 py-2.5">
                {error}
              </div>
            )}

            <button
              type="submit"
              className="w-full flex items-center justify-center gap-2 py-3 px-5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-sm font-semibold transition-colors"
            >
              <span>Continue to Dashboard</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* Live Goal Preview Card */}
          <div className="lg:col-span-4 rounded-2xl bg-[#0b1730] text-white p-7 border border-slate-800 space-y-5">
            <div className="flex items-center gap-2.5 text-cyan-300 text-xs font-semibold uppercase tracking-wider">
              <Droplets className="w-4 h-4" />
              <span>Calculated Goal</span>
            </div>

            <div>
              <div className="text-sm text-slate-300">Daily Hydration Target</div>
              <div className="text-4xl font-display font-bold font-mono-tabular mt-1 text-white">
                {calculatedTargetMl} <span className="text-lg font-normal text-cyan-300">ml</span>
              </div>
              <div className="mt-2 text-xs font-mono-tabular text-slate-400">
                Formula: {Number.isFinite(parsedWeight) && parsedWeight > 0 ? parsedWeight : 70} kg × 35 ml = {calculatedTargetMl} ml
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 space-y-2.5 text-sm text-slate-300">
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <span>Includes automatic +200ml offset tracking whenever you log coffee or energy drinks.</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <span>Syncs directly with your squad&apos;s HydroHero Leaderboard score.</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
