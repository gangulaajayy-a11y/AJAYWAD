import React, { useState } from 'react';
import {
  ArrowRight,
  Coffee,
  Droplets,
  MapPin,
  QrCode,
  Sprout,
  Trophy,
  Users,
} from 'lucide-react';
import type { RankedTeam, ThemeMode } from '../types/hydration';
import { BrandLockup } from './Logo';

interface LandingPageProps {
  onStartJourney: () => void;
  onQuickDemo: () => void;
  rankedTeams: RankedTeam[];
  theme: ThemeMode;
  onToggleTheme: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onStartJourney,
  onQuickDemo,
  rankedTeams,
  theme,
  onToggleTheme,
}) => {
  const [bottleFillPercent, setBottleFillPercent] = useState(68);
  const [imgErrSquad, setImgErrSquad] = useState(false);
  const [imgErrBottle, setImgErrBottle] = useState(false);

  const cycleBottleDemo = () => {
    setBottleFillPercent((prev) => (prev >= 96 ? 35 : Math.min(100, prev + 15)));
  };

  return (
    <div className="min-h-screen bg-[#f4f9ff] dark:bg-[#070e1d] text-slate-900 dark:text-slate-100">
      {/* 3-Zone Top Bar Contract */}
      <header className="sticky top-0 z-30 bg-white/90 dark:bg-[#070e1d]/90 backdrop-blur border-b border-slate-200/80 dark:border-slate-800/80">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between gap-8">
          <a
            href="#top"
            className="text-lg font-display font-bold tracking-tight text-slate-900 dark:text-white whitespace-nowrap shrink-0 flex items-center gap-2.5"
          >
            <BrandLockup />
          </a>

          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600 dark:text-slate-300" aria-label="Landing navigation">
            <a href="#features" className="hover:text-sky-600 dark:hover:text-cyan-400 transition-colors whitespace-nowrap shrink-0">
              Features
            </a>
            <a href="#how-it-works" className="hover:text-sky-600 dark:hover:text-cyan-400 transition-colors whitespace-nowrap shrink-0">
              How It Works
            </a>
            <a href="#competition" className="hover:text-sky-600 dark:hover:text-cyan-400 transition-colors whitespace-nowrap shrink-0">
              Squads
            </a>
            <a href="#impact" className="hover:text-sky-600 dark:hover:text-cyan-400 transition-colors whitespace-nowrap shrink-0">
              Impact
            </a>
          </nav>

          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={onStartJourney}
              className="px-4 py-2 text-sm font-semibold text-white bg-sky-600 hover:bg-sky-700 rounded-xl transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
            >
              Start Your Journey
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section id="top" className="max-w-7xl mx-auto px-6 pt-12 pb-16 lg:pt-16 lg:pb-24">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          <div className="lg:col-span-7 space-y-6">
            <div className="text-xs font-semibold tracking-[0.14em] text-sky-700 dark:text-cyan-400 uppercase">
              SIPSTREAK · HYDROHERO HUNT
            </div>

            <h1 className="font-display font-bold tracking-tight text-slate-900 dark:text-white text-[clamp(2.5rem,4.5vw,4rem)] leading-[1.06] max-w-2xl [text-wrap:balance]">
              Drink Together. Win Together.
            </h1>

            <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed max-w-xl">
              Built for college dorms, study squads, and office teams. Calculate your weight-based
              hydration target, offset every coffee automatically, grow a living plant companion,
              and climb the HydroHero squad leaderboard together.
            </p>

            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                type="button"
                onClick={onStartJourney}
                className="inline-flex items-center gap-2 px-6 py-3.5 text-sm font-semibold text-white bg-sky-600 hover:bg-sky-700 rounded-xl shadow-sm transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
              >
                <span>Start Your Journey</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <a
                href="#features"
                className="inline-flex items-center gap-2 px-6 py-3.5 text-sm font-semibold text-slate-800 dark:text-slate-100 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:border-sky-400 dark:hover:border-cyan-500 rounded-xl transition-colors whitespace-nowrap shrink-0"
              >
                <span>Explore Features</span>
              </a>

              <button
                type="button"
                onClick={onQuickDemo}
                className="text-sm font-medium text-sky-700 dark:text-cyan-400 hover:underline underline-offset-4 whitespace-nowrap shrink-0 px-2 py-2"
              >
                Open Live Demo Dashboard
              </button>
            </div>

            <div className="pt-4 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-slate-500 dark:text-slate-400">
              <span>Weight × 35ml Formula</span>
              <span aria-hidden="true">·</span>
              <span>4–8 Member Squads</span>
              <span aria-hidden="true">·</span>
              <span>Capped Fair Scoring</span>
              <span aria-hidden="true">·</span>
              <span>QR Bottle Quick-Log</span>
            </div>
          </div>

          {/* Animated Interactive Water Bottle Illustration */}
          <div className="lg:col-span-5">
            <div className="relative rounded-3xl bg-gradient-to-br from-[#0b1730] via-[#0e2247] to-[#081329] p-8 border border-slate-800 text-white shadow-xl overflow-hidden">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <div className="text-xs font-medium text-cyan-300">Interactive Hydration Bottle</div>
                  <div className="text-lg font-display font-semibold mt-0.5">
                    Tap bottle to test +15% sip fill
                  </div>
                </div>
                <button
                  type="button"
                  onClick={onToggleTheme}
                  className="text-xs font-medium text-slate-300 hover:text-white underline underline-offset-4"
                >
                  {theme === 'dark' ? 'Light mode' : 'Dark mode'}
                </button>
              </div>

              <div className="flex flex-col sm:flex-row items-center gap-8 justify-center">
                {/* Animated SVG Bottle */}
                <button
                  type="button"
                  onClick={cycleBottleDemo}
                  aria-label="Simulate pouring water into bottle"
                  className="group relative focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 rounded-2xl p-2 cursor-pointer"
                >
                  <svg
                    viewBox="0 0 180 300"
                    className="w-40 h-64 drop-shadow-lg transition-transform duration-200 group-hover:scale-[1.02]"
                    role="img"
                    aria-label={`Animated water bottle at ${bottleFillPercent}% hydration`}
                  >
                    <defs>
                      <clipPath id="hero-bottle-clip">
                        <path d="M58 62 C44 74 38 92 38 118 L38 256 C38 272 50 284 66 284 L114 284 C130 284 142 272 142 256 L142 118 C142 92 136 74 122 62 Z" />
                      </clipPath>
                      <linearGradient id="hero-water-grad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#22d3ee" />
                        <stop offset="55%" stopColor="#0284c7" />
                        <stop offset="100%" stopColor="#1d4ed8" />
                      </linearGradient>
                    </defs>

                    {/* Cap */}
                    <rect x="66" y="14" width="48" height="26" rx="7" fill="#0ea5e9" />
                    <rect x="62" y="38" width="56" height="12" rx="4" fill="#38bdf8" />
                    <path d="M68 50 L112 50 L120 62 L60 62 Z" fill="#1e3a8a" />

                    {/* Bottle Glass Outline */}
                    <path
                      d="M58 62 C44 74 38 92 38 118 L38 256 C38 272 50 284 66 284 L114 284 C130 284 142 272 142 256 L142 118 C142 92 136 74 122 62 Z"
                      fill="#0f2547"
                      stroke="#38bdf8"
                      strokeOpacity="0.45"
                      strokeWidth="2.5"
                    />

                    {/* Liquid Wave Fill */}
                    <g clipPath="url(#hero-bottle-clip)">
                      <g
                        style={{
                          transform: `translateY(${284 - (bottleFillPercent / 100) * 215}px)`,
                          transition: 'transform 500ms cubic-bezier(0.16, 1, 0.3, 1)',
                        }}
                      >
                        <g className="animate-wave-slow">
                          <path
                            d="M 0 0 Q 25 -10 50 0 T 100 0 T 150 0 T 200 0 T 250 0 T 300 0 L 300 260 L 0 260 Z"
                            fill="url(#hero-water-grad)"
                          />
                        </g>
                        <g className="animate-wave-fast" opacity="0.55">
                          <path
                            d="M 0 4 Q 25 12 50 4 T 100 4 T 150 4 T 200 4 T 250 4 T 300 4 L 300 260 L 0 260 Z"
                            fill="#67e8f9"
                          />
                        </g>
                      </g>
                    </g>

                    {/* Measurement Ticks */}
                    <line x1="126" y1="120" x2="136" y2="120" stroke="#93c5fd" strokeOpacity="0.55" strokeWidth="1.5" />
                    <line x1="126" y1="165" x2="136" y2="165" stroke="#93c5fd" strokeOpacity="0.55" strokeWidth="1.5" />
                    <line x1="126" y1="210" x2="136" y2="210" stroke="#93c5fd" strokeOpacity="0.55" strokeWidth="1.5" />
                    <line x1="126" y1="255" x2="136" y2="255" stroke="#93c5fd" strokeOpacity="0.55" strokeWidth="1.5" />

                    {/* Highlight Reflection */}
                    <path
                      d="M52 105 L52 248"
                      stroke="#ffffff"
                      strokeOpacity="0.22"
                      strokeWidth="4"
                      strokeLinecap="round"
                    />
                  </svg>
                </button>

                {/* Live Metric Readout */}
                <div className="space-y-4 text-center sm:text-left">
                  <div>
                    <div className="text-xs text-slate-400">Daily Target</div>
                    <div className="text-3xl font-display font-bold font-mono-tabular text-white">
                      {Math.round((bottleFillPercent / 100) * 2450)}{' '}
                      <span className="text-base font-normal text-cyan-300">/ 2450 ml</span>
                    </div>
                  </div>
                  <div className="space-y-1.5 text-sm">
                    <div className="flex items-center justify-between gap-6 border-b border-slate-700/60 pb-1.5">
                      <span className="text-slate-300">Completion</span>
                      <span className="font-mono-tabular font-semibold text-cyan-300">
                        {bottleFillPercent}%
                      </span>
                    </div>
                    <div className="flex items-center justify-between gap-6 border-b border-slate-700/60 pb-1.5">
                      <span className="text-slate-300">Squad Boost</span>
                      <span className="font-mono-tabular font-semibold text-emerald-300">
                        +{(bottleFillPercent / 6).toFixed(1)}%
                      </span>
                    </div>
                    <div className="flex items-center justify-between gap-6">
                      <span className="text-slate-300">Plant Stage</span>
                      <span className="font-medium text-white">
                        {bottleFillPercent >= 80 ? 'Healthy Foliage' : 'Growing Shoot'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Showcase (Asymmetric Bento Grid) */}
      <section id="features" className="max-w-7xl mx-auto px-6 py-16 border-t border-slate-200/80 dark:border-slate-800/80">
        <div className="max-w-2xl mb-10">
          <h2 className="font-display font-bold text-3xl sm:text-4xl tracking-tight text-slate-900 dark:text-white [text-wrap:balance]">
            Every feature engineered to keep teams consistent
          </h2>
          <p className="mt-3 text-slate-600 dark:text-slate-300">
            No guesswork, no solo burnout. Built around science-backed hydration math, fair team scoring, and campus utility.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Wide Feature Card 1 with Generated Squad Photo */}
          <div className="md:col-span-2 rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800 overflow-hidden grid grid-cols-1 sm:grid-cols-2">
            <div className="p-7 flex flex-col justify-between">
              <div>
                <Users className="w-6 h-6 text-sky-600 dark:text-cyan-400 mb-4" />
                <h3 className="font-display font-bold text-xl text-slate-900 dark:text-white">
                  Fair Capped Squad Scoring
                </h3>
                <p className="mt-2 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                  Squads of 4–8 members compete on normalized completion. Individual contributions cap at 100% so one marathon drinker cannot carry an inactive roster.
                </p>
              </div>
              <div className="mt-6 text-xs font-mono-tabular text-sky-700 dark:text-cyan-400">
                TeamScore = AVG(MIN(Intake / Goal, 1)) × 100
              </div>
            </div>
            <div className="min-h-[220px] bg-slate-100 dark:bg-slate-900 relative">
              {!imgErrSquad ? (
                <img
                  src="/src/assets/images/squad_challenge_scene_1795071025456.jpg"
                  alt="Students carrying reusable water bottles across campus courtyard"
                  referrerPolicy="no-referrer"
                  onError={() => setImgErrSquad(true)}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-sky-900 to-cyan-700 text-white p-6">
                  <Users className="w-10 h-10 opacity-80" />
                </div>
              )}
            </div>
          </div>

          {/* Caffeine Offset Card */}
          <div className="rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800 p-7 flex flex-col justify-between">
            <div>
              <Coffee className="w-6 h-6 text-amber-600 dark:text-amber-400 mb-4" />
              <h3 className="font-display font-bold text-xl text-slate-900 dark:text-white">
                Caffeine Offset Calculator
              </h3>
              <p className="mt-2 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                Every coffee or energy drink automatically adds +200ml to your effective daily hydration target while keeping your base target transparent.
              </p>
            </div>
            <div className="mt-6 text-xs font-mono-tabular text-slate-500 dark:text-slate-400">
              1 espresso / energy drink = +200 ml target
            </div>
          </div>

          {/* Virtual Plant Card */}
          <div className="rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800 p-7 flex flex-col justify-between">
            <div>
              <Sprout className="w-6 h-6 text-emerald-600 dark:text-emerald-400 mb-4" />
              <h3 className="font-display font-bold text-xl text-slate-900 dark:text-white">
                5-Stage Plant Companion
              </h3>
              <p className="mt-2 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                Watch your botanical buddy grow from seed to full bloom as your streak strengthens—or wilt gently when you fall behind.
              </p>
            </div>
            <div className="mt-6 text-xs text-slate-500 dark:text-slate-400">
              Seed · Sprout · Growing · Healthy · Bloom
            </div>
          </div>

          {/* Wide Feature Card 2: QR Bottle + Campus Map */}
          <div className="md:col-span-2 rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800 overflow-hidden grid grid-cols-1 sm:grid-cols-2">
            <div className="min-h-[220px] bg-slate-100 dark:bg-slate-900 relative order-2 sm:order-1">
              {!imgErrBottle ? (
                <img
                  src="/src/assets/images/smart_bottle_studio_1795071025249.jpg"
                  alt="Matte navy insulated hydration bottle with cyan accent"
                  referrerPolicy="no-referrer"
                  onError={() => setImgErrBottle(true)}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-slate-900 to-sky-900 text-white p-6">
                  <QrCode className="w-10 h-10 opacity-80" />
                </div>
              )}
            </div>
            <div className="p-7 flex flex-col justify-between order-1 sm:order-2">
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <QrCode className="w-5 h-5 text-sky-600 dark:text-cyan-400" />
                  <MapPin className="w-5 h-5 text-sky-600 dark:text-cyan-400" />
                </div>
                <h3 className="font-display font-bold text-xl text-slate-900 dark:text-white">
                  QR Bottle Stickers & Campus Map
                </h3>
                <p className="mt-2 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                  Print your personal QR code sticker to instant-log +500ml on scan, and locate nearby campus water refill stations on an interactive Leaflet map.
                </p>
              </div>
              <div className="mt-6 text-xs text-slate-500 dark:text-slate-400">
                Includes hourly daytime browser reminders
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="max-w-7xl mx-auto px-6 py-16 border-t border-slate-200/80 dark:border-slate-800/80">
        <h2 className="font-display font-bold text-3xl tracking-tight text-slate-900 dark:text-white mb-10">
          How It Works
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="space-y-3">
            <div className="text-sm font-mono-tabular font-semibold text-sky-600 dark:text-cyan-400">
              01. Personalize Your Target
            </div>
            <h3 className="font-display font-bold text-xl text-slate-900 dark:text-white">
              Weight-calibrated daily goal
            </h3>
            <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              Enter your body weight in kilograms during onboarding. SipStreak sets your baseline at WeightKg × 35 ml and adjusts dynamically whenever you log caffeine.
            </p>
          </div>
          <div className="space-y-3">
            <div className="text-sm font-mono-tabular font-semibold text-sky-600 dark:text-cyan-400">
              02. Build Your Squad
            </div>
            <h3 className="font-display font-bold text-xl text-slate-900 dark:text-white">
              Join or launch a 4–8 person team
            </h3>
            <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              Share a 6-character invite code with hostel wingmates, classmates, or office coworkers so every glass pushes your squad upward.
            </p>
          </div>
          <div className="space-y-3">
            <div className="text-sm font-mono-tabular font-semibold text-sky-600 dark:text-cyan-400">
              03. Log & Overtake Rivals
            </div>
            <h3 className="font-display font-bold text-xl text-slate-900 dark:text-white">
              One-tap intake & live podium
            </h3>
            <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              Tap +250ml, +500ml, or scan your bottle QR code. Every log recalculates your squad score in real time and triggers rank overtake alerts.
            </p>
          </div>
        </div>
      </section>

      {/* Team Competition Preview */}
      <section id="competition" className="max-w-7xl mx-auto px-6 py-16 border-t border-slate-200/80 dark:border-slate-800/80">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <h2 className="font-display font-bold text-3xl tracking-tight text-slate-900 dark:text-white">
              Live Squad Standings Preview
            </h2>
            <p className="mt-2 text-slate-600 dark:text-slate-300 text-sm">
              Real-time capped scoring across four demo campus squads.
            </p>
          </div>
          <button
            type="button"
            onClick={onQuickDemo}
            className="inline-flex items-center gap-2 text-sm font-semibold text-sky-600 dark:text-cyan-400 hover:underline whitespace-nowrap shrink-0"
          >
            <Trophy className="w-4 h-4" />
            <span>Enter Full Leaderboard</span>
          </button>
        </div>

        <div className="rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-500 dark:text-slate-400">
                  <th className="py-3.5 px-5">Rank</th>
                  <th className="py-3.5 px-5">Squad Name</th>
                  <th className="py-3.5 px-5 text-right">Members</th>
                  <th className="py-3.5 px-5 text-right">Total Consumed</th>
                  <th className="py-3.5 px-5 text-right">Team Score</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200/70 dark:divide-slate-800/70 text-sm">
                {rankedTeams.map((team) => (
                  <tr key={team.id} className="hover:bg-slate-50 dark:hover:bg-slate-900/40 transition-colors">
                    <td className="py-3.5 px-5 font-mono-tabular font-bold text-sky-700 dark:text-cyan-400">
                      #{team.rank}
                    </td>
                    <td className="py-3.5 px-5 font-semibold text-slate-900 dark:text-white">
                      {team.name}
                    </td>
                    <td className="py-3.5 px-5 text-right font-mono-tabular text-slate-600 dark:text-slate-300">
                      {team.members.length}
                    </td>
                    <td className="py-3.5 px-5 text-right font-mono-tabular text-slate-600 dark:text-slate-300">
                      {(team.totalIntakeMl / 1000).toFixed(2)} L
                    </td>
                    <td className="py-3.5 px-5 text-right font-mono-tabular font-bold text-slate-900 dark:text-white">
                      {team.teamScore.toFixed(1)}%
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Statistics Section */}
      <section id="impact" className="max-w-7xl mx-auto px-6 py-16 border-t border-slate-200/80 dark:border-slate-800/80">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="p-6 rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800">
            <div className="text-3xl font-display font-bold font-mono-tabular text-sky-600 dark:text-cyan-400">
              35 ml/kg
            </div>
            <div className="mt-1.5 text-sm font-medium text-slate-900 dark:text-white">
              Baseline Daily Formula
            </div>
            <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Personalized during onboarding
            </div>
          </div>
          <div className="p-6 rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800">
            <div className="text-3xl font-display font-bold font-mono-tabular text-sky-600 dark:text-cyan-400">
              +200 ml
            </div>
            <div className="mt-1.5 text-sm font-medium text-slate-900 dark:text-white">
              Caffeine Offset Rule
            </div>
            <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Per logged coffee or energy drink
            </div>
          </div>
          <div className="p-6 rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800">
            <div className="text-3xl font-display font-bold font-mono-tabular text-sky-600 dark:text-cyan-400">
              4–8
            </div>
            <div className="mt-1.5 text-sm font-medium text-slate-900 dark:text-white">
              Balanced Squad Roster
            </div>
            <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Optimal peer accountability size
            </div>
          </div>
          <div className="p-6 rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800">
            <div className="text-3xl font-display font-bold font-mono-tabular text-sky-600 dark:text-cyan-400">
              100%
            </div>
            <div className="mt-1.5 text-sm font-medium text-slate-900 dark:text-white">
              Capped Member Contribution
            </div>
            <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Prevents solo score distortion
            </div>
          </div>
        </div>
      </section>

      {/* Quiet Footer */}
      <footer className="border-t border-slate-200/80 dark:border-slate-800/80 bg-white dark:bg-[#0b1528]">
        <div className="max-w-7xl mx-auto px-6 py-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-slate-500 dark:text-slate-400">
          <div className="flex items-center gap-3">
            <Droplets className="w-4 h-4 text-sky-600 dark:text-cyan-400" />
            <span className="font-display font-semibold text-slate-800 dark:text-slate-200">
              SIPSTREAK: HYDROHERO HUNT
            </span>
          </div>
          <div className="flex items-center gap-6">
            <button type="button" onClick={onStartJourney} className="hover:text-slate-900 dark:hover:text-white">
              Sign Up
            </button>
            <button type="button" onClick={onQuickDemo} className="hover:text-slate-900 dark:hover:text-white">
              Demo Dashboard
            </button>
            <span>Collaborative Hydration Platform</span>
          </div>
        </div>
      </footer>
    </div>
  );
};
