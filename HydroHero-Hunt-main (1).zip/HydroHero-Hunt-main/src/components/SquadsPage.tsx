import React, { useState } from 'react';
import { Check, Copy, Plus, UserPlus, Users } from 'lucide-react';
import type { RankedTeam, UserProfile } from '../types/hydration';
import {
  MAX_SQUAD_SIZE,
  MIN_SQUAD_SIZE,
  calculateMemberCompletion,
  validateSquadSizeLimit,
} from '../utils/hydrationMath';

interface SquadsPageProps {
  user: UserProfile;
  rankedTeams: RankedTeam[];
  onJoinTeamByCode: (code: string) => { ok: boolean; message: string };
  onJoinTeamById: (teamId: string) => { ok: boolean; message: string };
  onCreateSquad: (name: string, description: string, maxMembers: number) => { ok: boolean; message: string };
}

export const SquadsPage: React.FC<SquadsPageProps> = ({
  user,
  rankedTeams,
  onJoinTeamByCode,
  onJoinTeamById,
  onCreateSquad,
}) => {
  const [inviteInput, setInviteInput] = useState('');
  const [joinFeedback, setJoinFeedback] = useState<{ ok: boolean; text: string } | null>(null);

  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newMaxSize, setNewMaxSize] = useState('6');
  const [createFeedback, setCreateFeedback] = useState<{ ok: boolean; text: string } | null>(null);

  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const activeTeam = rankedTeams.find((t) => t.id === user.teamId) ?? rankedTeams[0];

  const handleCopyCode = async (code: string) => {
    try {
      await navigator.clipboard.writeText(code);
    } catch {
      // Fallback visual confirmation still updates
    }
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const handleJoinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteInput.trim()) {
      setJoinFeedback({ ok: false, text: 'Enter a squad invite code.' });
      return;
    }
    const res = onJoinTeamByCode(inviteInput.trim().toUpperCase());
    setJoinFeedback({ ok: res.ok, text: res.message });
    if (res.ok) setInviteInput('');
  };

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newName.trim().length < 3) {
      setCreateFeedback({ ok: false, text: 'Squad name must be at least 3 characters.' });
      return;
    }
    const sizeCheck = validateSquadSizeLimit(Number(newMaxSize));
    if (!sizeCheck.valid) {
      setCreateFeedback({ ok: false, text: sizeCheck.error ?? 'Squad size must be between 4 and 8.' });
      return;
    }
    const res = onCreateSquad(newName.trim(), newDesc.trim(), sizeCheck.clamped);
    setCreateFeedback({ ok: res.ok, text: res.message });
    if (res.ok) {
      setNewName('');
      setNewDesc('');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="font-display font-bold text-2xl sm:text-3xl tracking-tight text-slate-900 dark:text-white">
            Team Squads
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
            Collaborate in squads of {MIN_SQUAD_SIZE}–{MAX_SQUAD_SIZE} members. Every member&apos;s capped completion lifts the squad score.
          </p>
        </div>
      </div>

      {/* Active Squad Hero Card */}
      {activeTeam && (
        <section
          aria-label="Your Active Squad"
          className="rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800 p-6 space-y-6"
        >
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-slate-200 dark:border-slate-800">
            <div>
              <div className="text-xs font-semibold text-sky-600 dark:text-cyan-400 uppercase tracking-wider">
                Active Squad · Rank #{activeTeam.rank}
              </div>
              <h2 className="font-display font-bold text-2xl text-slate-900 dark:text-white mt-1">
                {activeTeam.name}
              </h2>
              <p className="text-sm text-slate-600 dark:text-slate-300 mt-0.5">
                {activeTeam.description}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <div className="px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                <div className="text-[11px] text-slate-500 dark:text-slate-400">Invite Code</div>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="font-mono-tabular font-bold text-sm text-slate-900 dark:text-white">
                    {activeTeam.inviteCode}
                  </span>
                  <button
                    type="button"
                    onClick={() => handleCopyCode(activeTeam.inviteCode)}
                    aria-label={`Copy invite code ${activeTeam.inviteCode}`}
                    className="p-1 rounded-md text-sky-600 dark:text-cyan-400 hover:bg-sky-50 dark:hover:bg-sky-950/40"
                  >
                    {copiedCode === activeTeam.inviteCode ? (
                      <Check className="w-3.5 h-3.5" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </div>

              <div className="px-4 py-2.5 rounded-xl bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800/70">
                <div className="text-[11px] text-sky-700 dark:text-cyan-300">Team Score</div>
                <div className="font-mono-tabular font-bold text-lg text-sky-800 dark:text-cyan-200">
                  {activeTeam.teamScore.toFixed(1)}%
                </div>
              </div>
            </div>
          </div>

          {/* Squad Aggregate Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-900/70 border border-slate-200/70 dark:border-slate-800">
              <div className="text-xs text-slate-500 dark:text-slate-400">Total Team Water Intake</div>
              <div className="mt-1 text-xl font-display font-bold font-mono-tabular text-slate-900 dark:text-white">
                {(activeTeam.totalIntakeMl / 1000).toFixed(2)} L
              </div>
            </div>
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-900/70 border border-slate-200/70 dark:border-slate-800">
              <div className="text-xs text-slate-500 dark:text-slate-400">Roster Capacity</div>
              <div className="mt-1 text-xl font-display font-bold font-mono-tabular text-slate-900 dark:text-white">
                {activeTeam.members.length} / {activeTeam.maxMembers} members
              </div>
            </div>
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-900/70 border border-slate-200/70 dark:border-slate-800">
              <div className="text-xs text-slate-500 dark:text-slate-400">Collective Target</div>
              <div className="mt-1 text-xl font-display font-bold font-mono-tabular text-slate-900 dark:text-white">
                {(activeTeam.totalGoalMl / 1000).toFixed(2)} L
              </div>
            </div>
          </div>

          {/* Member Progress List */}
          <div>
            <h3 className="font-display font-semibold text-base text-slate-900 dark:text-white mb-3">
              Squad Roster & Individual Progress
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {activeTeam.members.map((member) => {
                const rawPct = member.goalMl > 0 ? Math.round((member.intakeMl / member.goalMl) * 100) : 0;
                const cappedScore = Math.round(calculateMemberCompletion(member.intakeMl, member.goalMl) * 100);
                return (
                  <div
                    key={member.id}
                    className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/40 space-y-2.5"
                  >
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-3 min-w-0">
                        <div
                          className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold text-white shrink-0"
                          style={{ backgroundColor: member.avatarColor }}
                          aria-hidden="true"
                        >
                          {member.avatarInitials}
                        </div>
                        <div className="min-w-0">
                          <div className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                            {member.name} {member.isCurrentUser ? '(You)' : ''}
                          </div>
                          <div className="text-xs text-slate-500 dark:text-slate-400">
                            {member.role} · {member.streakDays}d streak
                          </div>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <div className="text-sm font-mono-tabular font-bold text-slate-900 dark:text-white">
                          {cappedScore}%
                        </div>
                        <div className="text-[11px] font-mono-tabular text-slate-500 dark:text-slate-400">
                          {member.intakeMl} / {member.goalMl} ml
                        </div>
                      </div>
                    </div>

                    <div className="h-2 w-full rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-sky-500 to-cyan-400 transition-all duration-300"
                        style={{ width: `${Math.min(100, rawPct)}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>
      )}

      {/* Join by Code + Create Squad */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <section className="rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800 p-6 space-y-4">
          <div className="flex items-center gap-2.5">
            <UserPlus className="w-5 h-5 text-sky-600 dark:text-cyan-400" />
            <h2 className="font-display font-bold text-lg text-slate-900 dark:text-white">
              Join Squad via Invite Code
            </h2>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Enter a 6-character code such as AQUA26, HOMIE7, BLKA04, or BLKB08.
          </p>

          <form onSubmit={handleJoinSubmit} className="flex gap-2.5">
            <label htmlFor="squad-invite-code" className="sr-only">
              Squad invite code
            </label>
            <input
              id="squad-invite-code"
              type="text"
              value={inviteInput}
              onChange={(e) => setInviteInput(e.target.value)}
              placeholder="e.g. AQUA26"
              className="flex-1 px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-sm uppercase font-mono-tabular focus:outline-none focus:ring-2 focus:ring-sky-500"
            />
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-sm font-semibold whitespace-nowrap shrink-0"
            >
              Join Squad
            </button>
          </form>

          {joinFeedback && (
            <div
              role="status"
              className={`text-xs font-medium px-3.5 py-2 rounded-xl ${
                joinFeedback.ok
                  ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300'
                  : 'bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300'
              }`}
            >
              {joinFeedback.text}
            </div>
          )}
        </section>

        <section className="rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800 p-6 space-y-4">
          <div className="flex items-center gap-2.5">
            <Plus className="w-5 h-5 text-sky-600 dark:text-cyan-400" />
            <h2 className="font-display font-bold text-lg text-slate-900 dark:text-white">
              Create a New Squad
            </h2>
          </div>

          <form onSubmit={handleCreateSubmit} className="space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-2">
                <label htmlFor="create-squad-name" className="block text-xs font-medium mb-1">
                  Squad Name
                </label>
                <input
                  id="create-squad-name"
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="e.g. Robotics Lab"
                  className="w-full px-3.5 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              <div>
                <label htmlFor="create-squad-size" className="block text-xs font-medium mb-1">
                  Team Size (4–8)
                </label>
                <input
                  id="create-squad-size"
                  type="number"
                  min={MIN_SQUAD_SIZE}
                  max={MAX_SQUAD_SIZE}
                  value={newMaxSize}
                  onChange={(e) => setNewMaxSize(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-sm font-mono-tabular focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>
            </div>

            <div>
              <label htmlFor="create-squad-desc" className="block text-xs font-medium mb-1">
                Description (optional)
              </label>
              <input
                id="create-squad-desc"
                type="text"
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
                placeholder="Afternoon coding hydration pact"
                className="w-full px-3.5 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>

            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-slate-900 dark:bg-cyan-500 hover:bg-slate-800 dark:hover:bg-cyan-400 text-white dark:text-slate-950 text-sm font-semibold"
            >
              Launch Squad
            </button>

            {createFeedback && (
              <div
                role="status"
                className={`text-xs font-medium px-3.5 py-2 rounded-xl ${
                  createFeedback.ok
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300'
                    : 'bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300'
                }`}
              >
                {createFeedback.text}
              </div>
            )}
          </form>
        </section>
      </div>

      {/* Directory of All Campus Demo Squads */}
      <section className="rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800 p-6">
        <div className="flex items-center gap-2 mb-4">
          <Users className="w-5 h-5 text-sky-600 dark:text-cyan-400" />
          <h2 className="font-display font-bold text-lg text-slate-900 dark:text-white">
            Campus Squad Directory
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {rankedTeams.map((team) => {
            const isCurrent = team.id === user.teamId;
            return (
              <div
                key={team.id}
                className={`p-4 rounded-xl border transition-colors flex flex-col justify-between gap-3 ${
                  isCurrent
                    ? 'border-sky-500 dark:border-cyan-400 bg-sky-50/50 dark:bg-sky-950/25'
                    : 'border-slate-200 dark:border-slate-800'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="font-display font-bold text-base text-slate-900 dark:text-white">
                      {team.name}
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      {team.description}
                    </div>
                  </div>
                  <span className="font-mono-tabular text-sm font-bold text-sky-700 dark:text-cyan-300 shrink-0">
                    {team.teamScore.toFixed(1)}%
                  </span>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-200/60 dark:border-slate-800/60 text-xs">
                  <span className="font-mono-tabular text-slate-600 dark:text-slate-300">
                    {team.members.length}/{team.maxMembers} members · Code: <strong>{team.inviteCode}</strong>
                  </span>
                  {isCurrent ? (
                    <span className="font-semibold text-sky-700 dark:text-cyan-400">Your Squad</span>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        const res = onJoinTeamById(team.id);
                        setJoinFeedback({ ok: res.ok, text: res.message });
                      }}
                      className="font-semibold text-sky-600 dark:text-cyan-400 hover:underline"
                    >
                      Switch to Squad
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
};
