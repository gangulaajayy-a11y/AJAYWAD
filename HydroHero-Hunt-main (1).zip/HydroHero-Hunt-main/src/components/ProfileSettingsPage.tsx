import React, { useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { Bell, BellOff, Moon, QrCode, RotateCcw, Save, Sun } from 'lucide-react';
import type {
  ActivityLevel,
  ReminderSettings,
  ThemeMode,
  UserProfile,
} from '../types/hydration';
import { calculateDailyTarget } from '../utils/hydrationMath';

interface ProfileSettingsPageProps {
  user: UserProfile;
  theme: ThemeMode;
  reminders: ReminderSettings;
  onToggleTheme: () => void;
  onUpdateProfile: (updates: {
    name: string;
    weightKg: number;
    activityLevel: ActivityLevel;
  }) => void;
  onUpdateReminders: (next: ReminderSettings) => void;
  onSimulateQrScan: () => void;
  onResetDemoData: () => void;
}

export const ProfileSettingsPage: React.FC<ProfileSettingsPageProps> = ({
  user,
  theme,
  reminders,
  onToggleTheme,
  onUpdateProfile,
  onUpdateReminders,
  onSimulateQrScan,
  onResetDemoData,
}) => {
  const [name, setName] = useState(user.name);
  const [weightKg, setWeightKg] = useState(String(user.weightKg));
  const [activityLevel, setActivityLevel] = useState<ActivityLevel>(user.activityLevel);
  const [profileSaved, setProfileSaved] = useState('');

  const [permissionState, setPermissionState] = useState<NotificationPermission | 'unsupported'>(() => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      return 'unsupported';
    }
    return window.Notification.permission;
  });
  const [reminderStatusMsg, setReminderStatusMsg] = useState('');

  const qrUrl =
    typeof window !== 'undefined'
      ? `${window.location.origin}/?quicklog=500`
      : 'https://sipstreak.app/?quicklog=500';

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    const w = Number(weightKg);
    if (!name.trim() || !Number.isFinite(w) || w < 30 || w > 220) {
      setProfileSaved('Enter a valid name and weight (30–220 kg).');
      return;
    }
    onUpdateProfile({
      name: name.trim(),
      weightKg: Math.round(w),
      activityLevel,
    });
    setProfileSaved(`Saved! Daily base target updated to ${calculateDailyTarget(Math.round(w))} ml.`);
  };

  const handleToggleReminders = async () => {
    setReminderStatusMsg('');

    if (reminders.enabled) {
      onUpdateReminders({ ...reminders, enabled: false });
      setReminderStatusMsg('Hourly reminders paused.');
      return;
    }

    if (typeof window === 'undefined' || !('Notification' in window)) {
      setPermissionState('unsupported');
      onUpdateReminders({ ...reminders, enabled: false });
      setReminderStatusMsg('Browser notifications are not supported in this browser.');
      return;
    }

    if (window.Notification.permission === 'denied') {
      setPermissionState('denied');
      onUpdateReminders({ ...reminders, enabled: false });
      setReminderStatusMsg(
        'Browser notification permission is denied. Enable notifications in your browser site settings before activating reminders.',
      );
      return;
    }

    if (window.Notification.permission === 'granted') {
      setPermissionState('granted');
      onUpdateReminders({ ...reminders, enabled: true });
      setReminderStatusMsg('Hourly daytime hydration reminders are now active.');
      return;
    }

    try {
      const result = await window.Notification.requestPermission();
      setPermissionState(result);
      if (result === 'granted') {
        onUpdateReminders({ ...reminders, enabled: true });
        setReminderStatusMsg('Permission granted. Hourly daytime hydration reminders activated.');
      } else {
        onUpdateReminders({ ...reminders, enabled: false });
        setReminderStatusMsg(
          'Notification permission was not granted. Reminders remain disabled.',
        );
      }
    } catch {
      onUpdateReminders({ ...reminders, enabled: false });
      setReminderStatusMsg('Unable to request browser notification permission.');
    }
  };

  const handleSendTestReminder = () => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      setReminderStatusMsg('Browser notifications are unavailable here.');
      return;
    }
    if (window.Notification.permission !== 'granted') {
      setPermissionState(window.Notification.permission);
      setReminderStatusMsg('Cannot send browser notification until permission is granted.');
      return;
    }
    new window.Notification('SipStreak Hydration Check', {
      body: 'Time for a +250ml sip to keep your squad streak moving!',
    });
    setReminderStatusMsg('Test browser notification dispatched.');
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display font-bold text-2xl sm:text-3xl tracking-tight text-slate-900 dark:text-white">
          Profile, Reminders & QR Bottle
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
          Manage your hydration baseline, browser reminder schedule, theme, and personal bottle QR quick-logger.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Profile Form & Theme */}
        <section className="lg:col-span-7 rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800 p-6 space-y-5">
          <div className="flex items-center justify-between">
            <h2 className="font-display font-bold text-lg text-slate-900 dark:text-white">
              Hydration Profile & Goal
            </h2>
            <button
              type="button"
              onClick={onToggleTheme}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold hover:bg-slate-50 dark:hover:bg-slate-800"
            >
              {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              <span>{theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}</span>
            </button>
          </div>

          <form onSubmit={handleSaveProfile} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="prof-name" className="block text-xs font-medium mb-1">
                  Full Name
                </label>
                <input
                  id="prof-name"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              <div>
                <label htmlFor="prof-weight" className="block text-xs font-medium mb-1">
                  Body Weight (kg)
                </label>
                <input
                  id="prof-weight"
                  type="number"
                  min={30}
                  max={220}
                  value={weightKg}
                  onChange={(e) => setWeightKg(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-sm font-mono-tabular focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>
            </div>

            <div>
              <label htmlFor="prof-activity" className="block text-xs font-medium mb-1">
                Daily Activity Level
              </label>
              <select
                id="prof-activity"
                value={activityLevel}
                onChange={(e) => setActivityLevel(e.target.value as ActivityLevel)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
              >
                <option value="sedentary">Sedentary</option>
                <option value="moderate">Moderate</option>
                <option value="active">Active</option>
                <option value="athlete">Athlete</option>
              </select>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <div className="text-xs font-mono-tabular text-slate-500 dark:text-slate-400">
                Base Goal Preview: <strong>{calculateDailyTarget(Number(weightKg) || 70)} ml</strong>
              </div>
              <button
                type="submit"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-sm font-semibold"
              >
                <Save className="w-4 h-4" />
                <span>Save Profile</span>
              </button>
            </div>

            {profileSaved && (
              <div role="status" className="text-xs font-medium text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 px-3.5 py-2 rounded-xl">
                {profileSaved}
              </div>
            )}
          </form>

          {/* Hourly Hydration Reminders */}
          <div className="pt-5 border-t border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between gap-3">
              <div>
                <h3 className="font-display font-bold text-base text-slate-900 dark:text-white">
                  Hourly Hydration Reminders
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Permission status: <strong className="font-mono-tabular">{permissionState}</strong> ·{' '}
                  {reminders.enabled && permissionState === 'granted' ? 'Active' : 'Inactive'}
                </p>
              </div>

              <button
                type="button"
                onClick={handleToggleReminders}
                className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                  reminders.enabled && permissionState === 'granted'
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-900 dark:bg-cyan-500 text-white dark:text-slate-950'
                }`}
              >
                {reminders.enabled && permissionState === 'granted' ? (
                  <>
                    <Bell className="w-3.5 h-3.5" />
                    <span>Disable Reminders</span>
                  </>
                ) : (
                  <>
                    <BellOff className="w-3.5 h-3.5" />
                    <span>Enable Reminders</span>
                  </>
                )}
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label htmlFor="rem-start" className="block text-xs font-medium mb-1">
                  Start Hour (0–23)
                </label>
                <input
                  id="rem-start"
                  type="number"
                  min={0}
                  max={23}
                  value={reminders.startHour}
                  onChange={(e) =>
                    onUpdateReminders({ ...reminders, startHour: Number(e.target.value) })
                  }
                  className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-sm font-mono-tabular"
                />
              </div>

              <div>
                <label htmlFor="rem-end" className="block text-xs font-medium mb-1">
                  End Hour (0–23)
                </label>
                <input
                  id="rem-end"
                  type="number"
                  min={0}
                  max={23}
                  value={reminders.endHour}
                  onChange={(e) =>
                    onUpdateReminders({ ...reminders, endHour: Number(e.target.value) })
                  }
                  className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-sm font-mono-tabular"
                />
              </div>

              <div>
                <label htmlFor="rem-interval" className="block text-xs font-medium mb-1">
                  Interval (mins)
                </label>
                <select
                  id="rem-interval"
                  value={reminders.intervalMinutes}
                  onChange={(e) =>
                    onUpdateReminders({ ...reminders, intervalMinutes: Number(e.target.value) })
                  }
                  className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-sm font-mono-tabular"
                >
                  <option value={30}>Every 30 min</option>
                  <option value={60}>Every 60 min</option>
                  <option value={90}>Every 90 min</option>
                </select>
              </div>
            </div>

            <div className="flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={handleSendTestReminder}
                className="text-xs font-semibold text-sky-600 dark:text-cyan-400 hover:underline"
              >
                Send Test Notification
              </button>
              <button
                type="button"
                onClick={onResetDemoData}
                className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-500 hover:text-rose-600"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Demo Data</span>
              </button>
            </div>

            {reminderStatusMsg && (
              <div role="status" className="text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-900 px-3.5 py-2.5 rounded-xl">
                {reminderStatusMsg}
              </div>
            )}
          </div>
        </section>

        {/* QR Water Bottle Quick-Log Generator */}
        <section className="lg:col-span-5 rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800 p-6 flex flex-col justify-between space-y-5">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <QrCode className="w-5 h-5 text-sky-600 dark:text-cyan-400" />
              <h2 className="font-display font-bold text-lg text-slate-900 dark:text-white">
                QR Water Bottle Sticker
              </h2>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Stick this QR code on your bottle. Scanning it opens SipStreak with <code className="font-mono-tabular">?quicklog=500</code> and logs +500ml automatically.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white border border-slate-200 flex flex-col items-center justify-center text-center mx-auto">
            <QRCodeSVG
              value={qrUrl}
              size={180}
              bgColor="#ffffff"
              fgColor="#0b1730"
              level="M"
            />
            <div className="mt-3 text-xs font-display font-bold text-slate-900">
              {user.name} · +500ml Quick-Log
            </div>
            <div className="text-[11px] font-mono-tabular text-slate-500 break-all mt-0.5 max-w-[220px]">
              {qrUrl}
            </div>
          </div>

          <button
            type="button"
            onClick={onSimulateQrScan}
            className="w-full py-2.5 px-4 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-sm font-semibold transition-colors"
          >
            Simulate QR Scan (+500ml)
          </button>
        </section>
      </div>
    </div>
  );
};
