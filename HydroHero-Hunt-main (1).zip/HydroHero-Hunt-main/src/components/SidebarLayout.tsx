import React, { useState } from 'react';
import {
  BarChart3,
  Droplets,
  Home,
  LogOut,
  MapPin,
  Menu,
  Moon,
  Sprout,
  Sun,
  Trophy,
  UserCheck,
  Users,
  X,
} from 'lucide-react';
import type { AppView, ThemeMode, UserProfile } from '../types/hydration';
import { BrandLockup } from './Logo';

interface SidebarLayoutProps {
  activeView: AppView;
  onNavigate: (view: AppView) => void;
  user: UserProfile;
  theme: ThemeMode;
  onToggleTheme: () => void;
  onLogout: () => void;
  effectiveGoalMl: number;
  todayIntakeMl: number;
  children: React.ReactNode;
}

const NAV_ITEMS: Array<{ id: AppView; label: string; icon: React.ComponentType<{ className?: string }> }> = [
  { id: 'dashboard', label: 'Dashboard', icon: Droplets },
  { id: 'squads', label: 'Team Squads', icon: Users },
  { id: 'leaderboard', label: 'Leaderboard', icon: Trophy },
  { id: 'analytics', label: 'History', icon: BarChart3 },
  { id: 'plant', label: 'Plant Buddy', icon: Sprout },
  { id: 'map', label: 'Campus Map', icon: MapPin },
  { id: 'profile', label: 'Profile & QR', icon: UserCheck },
];

export const SidebarLayout: React.FC<SidebarLayoutProps> = ({
  activeView,
  onNavigate,
  user,
  theme,
  onToggleTheme,
  onLogout,
  effectiveGoalMl,
  todayIntakeMl,
  children,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const percent = effectiveGoalMl > 0 ? Math.min(100, Math.round((todayIntakeMl / effectiveGoalMl) * 100)) : 0;

  const handleNav = (view: AppView) => {
    onNavigate(view);
    setMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen flex bg-[#f3f8ff] dark:bg-[#070e1d] text-slate-900 dark:text-slate-100 transition-colors">
      {/* Persistent Desktop Sidebar */}
      <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:fixed lg:inset-y-0 bg-white dark:bg-[#0b1528] border-r border-slate-200/80 dark:border-slate-800/80 z-30">
        <div className="px-5 py-5 border-b border-slate-200/80 dark:border-slate-800/80">
          <button
            type="button"
            onClick={() => handleNav('landing')}
            className="text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 rounded-lg"
            aria-label="Go to SipStreak landing page"
          >
            <BrandLockup showSubtitle />
          </button>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto" aria-label="Primary application navigation">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNav(item.id)}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 ${
                  isActive
                    ? 'bg-sky-600 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70 hover:text-slate-900 dark:hover:text-white'
                }`}
                aria-current={isActive ? 'page' : undefined}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Daily Progress Summary & Account Actions */}
        <div className="p-4 border-t border-slate-200/80 dark:border-slate-800/80 space-y-3">
          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900/70 border border-slate-200/70 dark:border-slate-800">
            <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-1.5">
              <span>Today&apos;s Progress</span>
              <span className="font-mono-tabular font-semibold text-sky-700 dark:text-cyan-400">
                {percent}%
              </span>
            </div>
            <div className="h-1.5 w-full rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-sky-500 to-cyan-400 transition-all duration-300"
                style={{ width: `${percent}%` }}
              />
            </div>
            <div className="mt-1.5 text-xs font-mono-tabular text-slate-600 dark:text-slate-300">
              {todayIntakeMl} / {effectiveGoalMl} ml
            </div>
          </div>

          <div className="flex items-center justify-between gap-2">
            <div className="min-w-0">
              <div className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                {user.name}
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
                {user.streakDays}d streak · {user.weightKg} kg
              </div>
            </div>
            <div className="flex items-center gap-1 shrink-0">
              <button
                type="button"
                onClick={onToggleTheme}
                aria-label={theme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme'}
                className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </button>
              <button
                type="button"
                onClick={onLogout}
                aria-label="Sign out"
                className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-950/40 dark:hover:text-rose-400 transition-colors"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        {/* Compact Mobile / Tablet Header */}
        <header className="lg:hidden sticky top-0 z-30 flex items-center justify-between px-4 py-3 bg-white/95 dark:bg-[#0b1528]/95 backdrop-blur border-b border-slate-200/80 dark:border-slate-800/80">
          <button
            type="button"
            onClick={() => handleNav('dashboard')}
            className="focus-visible:outline-none"
            aria-label="SipStreak Dashboard"
          >
            <BrandLockup compact />
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onToggleTheme}
              aria-label={theme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme'}
              className="p-2 rounded-lg text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
            <button
              type="button"
              onClick={() => setMobileMenuOpen((v) => !v)}
              aria-label={mobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
              aria-expanded={mobileMenuOpen}
              className="p-2 rounded-lg text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </header>

        {/* Mobile Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden fixed inset-0 z-40 bg-slate-950/50 backdrop-blur-xs" onClick={() => setMobileMenuOpen(false)}>
            <nav
              className="w-72 max-w-[82vw] h-full bg-white dark:bg-[#0b1528] p-5 flex flex-col justify-between shadow-xl"
              onClick={(e) => e.stopPropagation()}
              aria-label="Mobile navigation"
            >
              <div>
                <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-200 dark:border-slate-800">
                  <BrandLockup showSubtitle />
                  <button
                    type="button"
                    onClick={() => setMobileMenuOpen(false)}
                    aria-label="Close menu"
                    className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <div className="space-y-1">
                  {NAV_ITEMS.map((item) => {
                    const Icon = item.icon;
                    const isActive = activeView === item.id;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => handleNav(item.id)}
                        className={`w-full flex items-center gap-3 px-3.5 py-3 rounded-xl text-sm font-medium ${
                          isActive
                            ? 'bg-sky-600 text-white'
                            : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                      >
                        <Icon className="w-4 h-4" />
                        <span>{item.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
              <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-2">
                <button
                  type="button"
                  onClick={() => handleNav('landing')}
                  className="w-full flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  <Home className="w-4 h-4" />
                  <span>Landing Page</span>
                </button>
                <button
                  type="button"
                  onClick={onLogout}
                  className="w-full flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-sm text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Sign Out</span>
                </button>
              </div>
            </nav>
          </div>
        )}

        <main className="flex-1 px-4 sm:px-6 lg:px-8 py-6 pb-20 lg:pb-8 max-w-[1360px] w-full mx-auto">
          {children}
        </main>
      </div>

      {/* Compact Mobile Bottom Tab Bar (under 15% mobile height) */}
      <nav
        className="lg:hidden fixed bottom-0 inset-x-0 z-30 bg-white/95 dark:bg-[#0b1528]/95 backdrop-blur border-t border-slate-200/80 dark:border-slate-800/80 grid grid-cols-5 px-1 py-1"
        aria-label="Mobile quick tabs"
      >
        {[
          { id: 'dashboard' as AppView, label: 'Hydrate', icon: Droplets },
          { id: 'squads' as AppView, label: 'Squads', icon: Users },
          { id: 'leaderboard' as AppView, label: 'Ranks', icon: Trophy },
          { id: 'plant' as AppView, label: 'Plant', icon: Sprout },
          { id: 'map' as AppView, label: 'Map', icon: MapPin },
        ].map((tab) => {
          const Icon = tab.icon;
          const active = activeView === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => handleNav(tab.id)}
              className={`flex flex-col items-center justify-center py-1.5 rounded-lg text-[11px] font-medium ${
                active
                  ? 'text-sky-600 dark:text-cyan-400'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              <Icon className="w-4 h-4 mb-0.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
};
