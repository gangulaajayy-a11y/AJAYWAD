import React from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { Award, CalendarCheck2, Flame, TrendingUp } from 'lucide-react';
import type { DailyHistoryEntry, UserProfile } from '../types/hydration';
import { calculateAnalyticsSummary } from '../utils/hydrationMath';

interface AnalyticsPageProps {
  history: DailyHistoryEntry[];
  todayIntakeMl: number;
  effectiveGoalMl: number;
  user: UserProfile;
}

export const AnalyticsPage: React.FC<AnalyticsPageProps> = ({
  history,
  todayIntakeMl,
  effectiveGoalMl,
  user,
}) => {
  const summary = calculateAnalyticsSummary(history, todayIntakeMl, effectiveGoalMl);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display font-bold text-2xl sm:text-3xl tracking-tight text-slate-900 dark:text-white">
          Hydration History & Analytics
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
          7-day intake trends, goal consistency, and personal vs. squad pace. Today updates live as you log water.
        </p>
      </div>

      {/* KPI Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Weekly Average</span>
            <TrendingUp className="w-4 h-4 text-sky-600 dark:text-cyan-400" />
          </div>
          <div className="mt-2 text-2xl font-display font-bold font-mono-tabular text-slate-900 dark:text-white">
            {summary.weeklyAverageMl} ml
          </div>
          <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Target: {effectiveGoalMl} ml/day
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Best Hydration Day</span>
            <Award className="w-4 h-4 text-amber-500" />
          </div>
          <div className="mt-2 text-2xl font-display font-bold font-mono-tabular text-slate-900 dark:text-white">
            {summary.bestDay.intakeMl} ml
          </div>
          <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            {summary.bestDay.day} · {summary.bestDay.date}
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Current Streak</span>
            <Flame className="w-4 h-4 text-amber-500" />
          </div>
          <div className="mt-2 text-2xl font-display font-bold font-mono-tabular text-slate-900 dark:text-white">
            {user.streakDays} days
          </div>
          <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Longest streak: {user.longestStreakDays} days
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Goal Days Hit</span>
            <CalendarCheck2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          </div>
          <div className="mt-2 text-2xl font-display font-bold font-mono-tabular text-slate-900 dark:text-white">
            {summary.daysHitGoal} / {summary.series.length}
          </div>
          <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Past 7-day window
          </div>
        </div>
      </div>

      {/* 7-Day Bar Chart */}
      <section className="rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800 p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6">
          <div>
            <h2 className="font-display font-bold text-lg text-slate-900 dark:text-white">
              7-Day Water Intake vs Daily Goal
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Dashed reference line marks your current effective goal ({effectiveGoalMl} ml).
            </p>
          </div>
        </div>

        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={summary.series} margin={{ top: 18, right: 16, left: 4, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148, 163, 184, 0.25)" vertical={false} />
              <XAxis dataKey="day" tick={{ fontSize: 12 }} stroke="#94a3b8" />
              <YAxis
                tick={{ fontSize: 12 }}
                stroke="#94a3b8"
                tickFormatter={(v) => `${v} ml`}
                width={72}
              />
              <Tooltip
                contentStyle={{
                  borderRadius: '12px',
                  border: '1px solid #cbd5e1',
                  fontSize: '12px',
                }}
              />
              <ReferenceLine
                y={effectiveGoalMl}
                stroke="#06b6d4"
                strokeDasharray="5 5"
                label={{ value: `Goal ${effectiveGoalMl}ml`, position: 'insideTopRight', fill: '#0891b2', fontSize: 11 }}
              />
              <Bar dataKey="intakeMl" name="Your Intake (ml)" fill="#0284c7" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>

      {/* Team vs Personal Comparison */}
      <section className="rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800 p-6">
        <div className="mb-6">
          <h2 className="font-display font-bold text-lg text-slate-900 dark:text-white">
            Personal Intake vs. Squad Average
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Compare your daily consistency against your team&apos;s average hydration pace.
          </p>
        </div>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={summary.series} margin={{ top: 10, right: 16, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148, 163, 184, 0.25)" vertical={false} />
              <XAxis dataKey="day" tick={{ fontSize: 12 }} stroke="#94a3b8" />
              <YAxis tick={{ fontSize: 12 }} stroke="#94a3b8" width={55} />
              <Tooltip
                contentStyle={{
                  borderRadius: '12px',
                  border: '1px solid #cbd5e1',
                  fontSize: '12px',
                }}
              />
              <Legend wrapperStyle={{ fontSize: '12px' }} />
              <Line
                type="monotone"
                dataKey="intakeMl"
                name="Your Intake (ml)"
                stroke="#0284c7"
                strokeWidth={3}
                dot={{ r: 4 }}
              />
              <Line
                type="monotone"
                dataKey="teamAvgMl"
                name="Squad Average (ml)"
                stroke="#06b6d4"
                strokeWidth={2.5}
                strokeDasharray="4 4"
                dot={{ r: 3 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </section>
    </div>
  );
};
