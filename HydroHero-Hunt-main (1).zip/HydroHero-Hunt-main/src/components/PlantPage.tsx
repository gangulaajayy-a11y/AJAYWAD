import React, { useState } from 'react';
import { Droplets, Sparkles, Sprout } from 'lucide-react';
import type { PlantStageId, UserProfile } from '../types/hydration';
import { computePlantStatus } from '../utils/hydrationMath';

interface PlantPageProps {
  todayIntakeMl: number;
  effectiveGoalMl: number;
  user: UserProfile;
  onQuickWater: (amountMl: number, label: string) => void;
}

const STAGE_LIST: Array<{ id: PlantStageId; title: string; rule: string }> = [
  { id: 'seed', title: '1. Seed', rule: '0% – 17% daily goal' },
  { id: 'sprout', title: '2. Small Sprout', rule: '18% – 44% daily goal' },
  { id: 'growing', title: '3. Growing Plant', rule: '45% – 79% daily goal' },
  { id: 'healthy', title: '4. Healthy Plant', rule: '80%+ daily goal' },
  { id: 'blooming', title: '5. Fully Grown', rule: '100% goal + 4d streak' },
];

export const PlantPage: React.FC<PlantPageProps> = ({
  todayIntakeMl,
  effectiveGoalMl,
  user,
  onQuickWater,
}) => {
  const [previewNeglect, setPreviewNeglect] = useState(false);

  const status = computePlantStatus(
    todayIntakeMl,
    effectiveGoalMl,
    user.streakDays,
    previewNeglect,
  );

  const leafColor = status.isWilted ? '#a3a352' : '#10b981';
  const leafDark = status.isWilted ? '#78713c' : '#047857';
  const stemColor = status.isWilted ? '#848447' : '#059669';

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="font-display font-bold text-2xl sm:text-3xl tracking-tight text-slate-900 dark:text-white">
            Virtual Plant Companion
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
            Your HydroFern thrives when you hit your hydration milestones and wilts if water intake is neglected.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setPreviewNeglect((v) => !v)}
          className={`px-4 py-2 rounded-xl text-xs font-semibold border transition-colors self-start sm:self-auto whitespace-nowrap shrink-0 ${
            previewNeglect
              ? 'bg-amber-100 dark:bg-amber-950/50 border-amber-400 text-amber-800 dark:text-amber-300'
              : 'bg-white dark:bg-[#0d1930] border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200'
          }`}
        >
          {previewNeglect ? 'Exit Wilt Preview' : 'Preview Neglected Wilt State'}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* Terrarium Illustration Canvas */}
        <section className="lg:col-span-6 rounded-2xl bg-gradient-to-b from-sky-50 to-emerald-50/40 dark:from-[#0b1830] dark:to-[#081a24] border border-slate-200 dark:border-slate-800 p-8 flex flex-col items-center justify-center relative overflow-hidden">
          <div className="w-full flex items-center justify-between text-xs font-medium text-slate-600 dark:text-slate-300 mb-4">
            <span>Stage {status.stageIndex} of 5 · {status.stageLabel}</span>
            <span className="font-mono-tabular font-semibold">Health {status.healthPercent}%</span>
          </div>

          <svg
            viewBox="0 0 260 260"
            className="w-64 h-64"
            role="img"
            aria-label={`Virtual plant companion at stage ${status.stageLabel}${status.isWilted ? ', currently wilting' : ''}`}
          >
            {/* Terracotta / Ceramic Pot */}
            <path d="M82 182 L178 182 L166 238 C165 243 160 246 154 246 L106 246 C100 246 95 243 94 238 Z" fill="#0f294a" />
            <rect x="74" y="170" width="112" height="16" rx="6" fill="#1e3a8a" />
            {/* Soil */}
            <ellipse cx="130" cy="172" rx="46" ry="7" fill="#3f2e21" />

            {/* Plant Geometry by Stage */}
            <g className={status.isWilted ? '' : 'animate-plant-sway'}>
              {status.stage === 'seed' && (
                <g>
                  <ellipse cx="130" cy="168" rx="10" ry="7" fill="#926239" />
                  <path
                    d="M130 162 Q132 152 138 148"
                    stroke={stemColor}
                    strokeWidth="3"
                    strokeLinecap="round"
                    fill="none"
                  />
                </g>
              )}

              {status.stage === 'sprout' && (
                <g transform={status.isWilted ? 'rotate(14 130 170)' : undefined}>
                  <path
                    d={status.isWilted ? 'M130 172 Q138 148 146 142' : 'M130 172 Q130 144 130 132'}
                    stroke={stemColor}
                    strokeWidth="4.5"
                    strokeLinecap="round"
                    fill="none"
                  />
                  <ellipse
                    cx={status.isWilted ? 136 : 118}
                    cy={status.isWilted ? 148 : 132}
                    rx="14"
                    ry="7"
                    transform={status.isWilted ? 'rotate(25 136 148)' : 'rotate(-24 118 132)'}
                    fill={leafColor}
                  />
                  <ellipse
                    cx={status.isWilted ? 156 : 142}
                    cy={status.isWilted ? 150 : 132}
                    rx="14"
                    ry="7"
                    transform={status.isWilted ? 'rotate(38 156 150)' : 'rotate(24 142 132)'}
                    fill={leafDark}
                  />
                </g>
              )}

              {status.stage === 'growing' && (
                <g>
                  <path d="M130 172 Q128 135 130 100" stroke={stemColor} strokeWidth="5" strokeLinecap="round" fill="none" />
                  <ellipse cx="108" cy="138" rx="20" ry="9" transform="rotate(-25 108 138)" fill={leafColor} />
                  <ellipse cx="152" cy="130" rx="20" ry="9" transform="rotate(25 152 130)" fill={leafDark} />
                  <ellipse cx="112" cy="108" rx="17" ry="8" transform="rotate(-30 112 108)" fill={leafColor} />
                  <ellipse cx="146" cy="104" rx="17" ry="8" transform="rotate(30 146 104)" fill={leafColor} />
                </g>
              )}

              {(status.stage === 'healthy' || status.stage === 'blooming') && (
                <g>
                  <path d="M130 172 Q128 125 130 74" stroke={stemColor} strokeWidth="6" strokeLinecap="round" fill="none" />
                  <path d="M130 140 Q105 128 96 116" stroke={stemColor} strokeWidth="3.5" strokeLinecap="round" fill="none" />
                  <path d="M130 132 Q156 120 165 108" stroke={stemColor} strokeWidth="3.5" strokeLinecap="round" fill="none" />
                  <ellipse cx="94" cy="136" rx="24" ry="11" transform="rotate(-20 94 136)" fill={leafDark} />
                  <ellipse cx="166" cy="134" rx="24" ry="11" transform="rotate(20 166 134)" fill={leafColor} />
                  <ellipse cx="98" cy="108" rx="22" ry="10" transform="rotate(-28 98 108)" fill={leafColor} />
                  <ellipse cx="162" cy="104" rx="22" ry="10" transform="rotate(28 162 104)" fill={leafDark} />
                  <ellipse cx="114" cy="84" rx="18" ry="8" transform="rotate(-32 114 84)" fill={leafColor} />
                  <ellipse cx="146" cy="84" rx="18" ry="8" transform="rotate(32 146 84)" fill={leafColor} />

                  {status.stage === 'blooming' && (
                    <g>
                      <circle cx="130" cy="60" r="14" fill="#38bdf8" />
                      <circle cx="118" cy="64" r="9" fill="#22d3ee" />
                      <circle cx="142" cy="64" r="9" fill="#22d3ee" />
                      <circle cx="130" cy="50" r="9" fill="#7dd3fc" />
                      <circle cx="130" cy="62" r="6" fill="#fde047" />
                    </g>
                  )}
                </g>
              )}
            </g>
          </svg>

          <p className="mt-4 text-center text-sm font-medium text-slate-700 dark:text-slate-200 max-w-sm">
            {status.message}
          </p>

          <button
            type="button"
            onClick={() => {
              setPreviewNeglect(false);
              onQuickWater(250, 'Watered Plant (+250ml)');
            }}
            className="mt-5 inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-sm font-semibold transition-colors"
          >
            <Droplets className="w-4 h-4" />
            <span>Water Buddy (+250ml)</span>
          </button>
        </section>

        {/* Growth Stages & Encouragement */}
        <section className="lg:col-span-6 rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800 p-6 flex flex-col justify-between space-y-6">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Sprout className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
              <h2 className="font-display font-bold text-lg text-slate-900 dark:text-white">
                Botanical Growth Milestones
              </h2>
            </div>

            <div className="space-y-3">
              {STAGE_LIST.map((item, idx) => {
                const reached = status.stageIndex >= idx + 1 && !status.isWilted;
                const current = status.stage === item.id && !status.isWilted;
                return (
                  <div
                    key={item.id}
                    className={`p-3.5 rounded-xl border flex items-center justify-between ${
                      current
                        ? 'border-emerald-500 bg-emerald-50/70 dark:bg-emerald-950/30'
                        : reached
                          ? 'border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/30'
                          : 'border-slate-200/70 dark:border-slate-800/60 opacity-75'
                    }`}
                  >
                    <div>
                      <div className="text-sm font-semibold text-slate-900 dark:text-white">
                        {item.title}
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">{item.rule}</div>
                    </div>
                    <span
                      className={`text-xs font-semibold ${
                        current
                          ? 'text-emerald-700 dark:text-emerald-300'
                          : reached
                            ? 'text-sky-700 dark:text-cyan-400'
                            : 'text-slate-400'
                      }`}
                    >
                      {current ? 'Current Stage' : reached ? 'Unlocked' : 'Locked'}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="p-4 rounded-xl bg-sky-50 dark:bg-sky-950/30 border border-sky-200/70 dark:border-sky-900/60 flex items-start gap-3">
            <Sparkles className="w-4 h-4 text-sky-600 dark:text-cyan-400 shrink-0 mt-0.5" />
            <div className="text-xs text-slate-700 dark:text-slate-200">
              <strong>Next Milestone:</strong> {status.nextMilestoneText}
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};
