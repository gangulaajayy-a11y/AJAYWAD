import React, { useState } from 'react';
import {
  Coffee,
  Droplets,
  Flame,
  Plus,
  Trash2,
  Trophy,
  Zap,
} from 'lucide-react';
import type {
  AppView,
  CaffeineLog,
  RankedTeam,
  UserProfile,
  WaterLog,
} from '../types/hydration';

interface DashboardPageProps {
  user: UserProfile;
  waterLogs: WaterLog[];
  caffeineLogs: CaffeineLog[];
  todayIntakeMl: number;
  caffeineOffsetMl: number;
  effectiveGoalMl: number;
  weeklyAverageMl: number;
  userTeam: RankedTeam | undefined;
  onLogWater: (amountMl: number, label: string, source: WaterLog['source']) => void;
  onDeleteWaterLog: (id: string) => void;
  onLogCaffeine: (drinkType: CaffeineLog['drinkType'], label: string) => void;
  onDeleteCaffeineLog: (id: string) => void;
  onNavigate: (view: AppView) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({
  user,
  waterLogs,
  caffeineLogs,
  todayIntakeMl,
  caffeineOffsetMl,
  effectiveGoalMl,
  weeklyAverageMl,
  userTeam,
  onLogWater,
  onDeleteWaterLog,
  onLogCaffeine,
  onDeleteCaffeineLog,
  onNavigate,
}) => {
  const [customMl, setCustomMl] = useState('350');
  const [customError, setCustomError] = useState('');

  const completionRatio = effectiveGoalMl > 0 ? todayIntakeMl / effectiveGoalMl : 0;
  const percentCompleted = Math.min(100, Math.round(completionRatio * 100));
  const remainingMl = Math.max(0, effectiveGoalMl - todayIntakeMl);

  const ringRadius = 104;
  const ringCircumference = 2 * Math.PI * ringRadius;
  const strokeDashoffset = ringCircumference * (1 - Math.min(1, completionRatio));

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCustomError('');
    const amt = Number(customMl);
    if (!Number.isFinite(amt) || amt < 25 || amt > 3000) {
      setCustomError('Enter an amount between 25 ml and 3000 ml.');
      return;
    }
    onLogWater(Math.round(amt), `Custom (${Math.round(amt)} ml)`, 'custom');
  };

  // Merge timeline entries sorted newest first
  const timeline = [
    ...waterLogs.map((w) => ({
      kind: 'water' as const,
      id: w.id,
      label: w.label,
      amountText: `+${w.amountMl} ml`,
      timestamp: w.timestamp,
    })),
    ...caffeineLogs.map((c) => ({
      kind: 'caffeine' as const,
      id: c.id,
      label: c.label,
      amountText: `+${c.offsetMl} ml offset`,
      timestamp: c.timestamp,
    })),
  ].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  const formatTime = (iso: string) => {
    try {
      return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch {
      return '';
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="font-display font-bold text-2xl sm:text-3xl tracking-tight text-slate-900 dark:text-white">
            Hydration Dashboard
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
            {user.name} · Base target {user.baseGoalMl} ml ({user.weightKg} kg × 35)
            {caffeineOffsetMl > 0 ? ` + ${caffeineOffsetMl} ml caffeine offset` : ''}
          </p>
        </div>

        {userTeam && (
          <button
            type="button"
            onClick={() => onNavigate('leaderboard')}
            className="inline-flex items-center gap-2.5 px-4 py-2 rounded-xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800 hover:border-sky-400 dark:hover:border-cyan-500 text-sm transition-colors self-start sm:self-auto whitespace-nowrap shrink-0"
          >
            <Trophy className="w-4 h-4 text-sky-600 dark:text-cyan-400" />
            <span className="font-semibold text-slate-900 dark:text-white">{userTeam.name}</span>
            <span className="font-mono-tabular text-sky-700 dark:text-cyan-400 font-semibold">
              #{userTeam.rank} · {userTeam.teamScore.toFixed(1)}%
            </span>
          </button>
        )}
      </div>

      {/* Top 5 Key Metrics Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
        <div className="p-4 rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">Today&apos;s Intake</div>
          <div className="mt-1 text-2xl font-display font-bold font-mono-tabular text-slate-900 dark:text-white" data-testid="today-intake">
            {todayIntakeMl} ml
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">Remaining Water</div>
          <div className="mt-1 text-2xl font-display font-bold font-mono-tabular text-sky-600 dark:text-cyan-400" data-testid="remaining-water">
            {remainingMl} ml
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">Current Streak</div>
          <div className="mt-1 text-2xl font-display font-bold font-mono-tabular text-slate-900 dark:text-white flex items-center gap-1.5">
            <Flame className="w-5 h-5 text-amber-500" />
            <span>{user.streakDays} days</span>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">Weekly Average</div>
          <div className="mt-1 text-2xl font-display font-bold font-mono-tabular text-slate-900 dark:text-white">
            {weeklyAverageMl} ml
          </div>
        </div>

        <div className="col-span-2 sm:col-span-1 p-4 rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">Daily Target</div>
          <div className="mt-1 text-2xl font-display font-bold font-mono-tabular text-slate-900 dark:text-white" data-testid="effective-target">
            {effectiveGoalMl} ml
          </div>
          {caffeineOffsetMl > 0 && (
            <div className="text-[11px] font-mono-tabular text-amber-600 dark:text-amber-400 mt-0.5">
              Base {user.baseGoalMl} + {caffeineOffsetMl} offset
            </div>
          )}
        </div>
      </div>

      {/* Main Split: Personal Hydration Ring + Quick Logging & Caffeine Offset */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* Personal Hydration Ring */}
        <section
          aria-label="Personal Hydration Ring"
          className="lg:col-span-5 rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800 p-6 flex flex-col items-center justify-center text-center"
        >
          <div className="relative w-64 h-64 flex items-center justify-center">
            <svg viewBox="0 0 240 240" className="w-full h-full -rotate-90" aria-hidden="true">
              <defs>
                <linearGradient id="ring-progress-grad" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#06b6d4" />
                  <stop offset="100%" stopColor="#0284c7" />
                </linearGradient>
                <clipPath id="inner-wave-clip">
                  <circle cx="120" cy="120" r="88" />
                </clipPath>
              </defs>

              {/* Track */}
              <circle
                cx="120"
                cy="120"
                r={ringRadius}
                fill="none"
                stroke="currentColor"
                className="text-slate-100 dark:text-slate-800"
                strokeWidth="16"
              />

              {/* Animated Progress Arc */}
              <circle
                cx="120"
                cy="120"
                r={ringRadius}
                fill="none"
                stroke="url(#ring-progress-grad)"
                strokeWidth="16"
                strokeLinecap="round"
                strokeDasharray={ringCircumference}
                strokeDashoffset={strokeDashoffset}
                style={{ transition: 'stroke-dashoffset 450ms cubic-bezier(0.16, 1, 0.3, 1)' }}
              />
            </svg>

            {/* Inner Animated Wave Circle */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="w-[172px] h-[172px] rounded-full overflow-hidden relative bg-sky-50 dark:bg-slate-900/90 border border-sky-100 dark:border-slate-800 flex flex-col items-center justify-center">
                <div
                  className="absolute inset-x-0 bottom-0 transition-all duration-500 ease-out overflow-hidden"
                  style={{ height: `${Math.max(8, percentCompleted)}%` }}
                >
                  <svg
                    viewBox="0 0 200 40"
                    preserveAspectRatio="none"
                    className="w-[200%] h-5 animate-wave-slow opacity-35 dark:opacity-45 -mt-2"
                  >
                    <path
                      d="M0 15 Q 25 0 50 15 T 100 15 T 150 15 T 200 15 V 40 H 0 Z"
                      fill="#06b6d4"
                    />
                  </svg>
                  <div className="w-full h-full bg-gradient-to-t from-sky-500/25 via-cyan-400/20 to-cyan-300/15" />
                </div>

                <div className="relative z-10 px-2">
                  <div className="text-4xl font-display font-bold font-mono-tabular text-slate-900 dark:text-white" data-testid="hydration-percent">
                    {percentCompleted}%
                  </div>
                  <div className="text-sm font-mono-tabular font-semibold text-sky-700 dark:text-cyan-300 mt-0.5">
                    {todayIntakeMl} ml
                  </div>
                  <div className="text-xs font-mono-tabular text-slate-500 dark:text-slate-400">
                    of {effectiveGoalMl} ml
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 w-full max-w-xs pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-600 dark:text-slate-300">
            <span>Base Goal: <strong className="font-mono-tabular">{user.baseGoalMl} ml</strong></span>
            <span>Caffeine Offset: <strong className="font-mono-tabular text-amber-600 dark:text-amber-400">+{caffeineOffsetMl} ml</strong></span>
          </div>
        </section>

        {/* Quick Water Logging & Caffeine Offset Calculator */}
        <div className="lg:col-span-7 flex flex-col gap-6">
          {/* Quick Water Logging */}
          <section
            aria-label="Quick Water Logging"
            className="rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800 p-6 space-y-4"
          >
            <div className="flex items-center justify-between">
              <div>
                <h2 className="font-display font-bold text-lg text-slate-900 dark:text-white">
                  Quick Water Logging
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Every log updates your ring, squad total, and leaderboard rank instantly.
                </p>
              </div>
              <Droplets className="w-5 h-5 text-sky-600 dark:text-cyan-400" />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <button
                type="button"
                onClick={() => onLogWater(250, 'Water Cup', 'cup')}
                className="flex flex-col items-start p-4 rounded-xl bg-sky-50 dark:bg-sky-950/40 hover:bg-sky-100 dark:hover:bg-sky-900/50 border border-sky-200 dark:border-sky-800/80 transition-colors text-left"
              >
                <span className="font-mono-tabular font-bold text-lg text-sky-700 dark:text-cyan-300">
                  +250ml Cup
                </span>
                <span className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">
                  Standard desk glass
                </span>
              </button>

              <button
                type="button"
                onClick={() => onLogWater(500, 'Water Bottle', 'bottle')}
                className="flex flex-col items-start p-4 rounded-xl bg-sky-600 hover:bg-sky-700 text-white transition-colors text-left shadow-xs"
              >
                <span className="font-mono-tabular font-bold text-lg">
                  +500ml Bottle
                </span>
                <span className="text-xs text-sky-100 mt-0.5">
                  Half-liter refill
                </span>
              </button>

              <button
                type="button"
                onClick={() => onLogWater(750, 'Sports Tumbler', 'tumbler')}
                className="flex flex-col items-start p-4 rounded-xl bg-sky-50 dark:bg-sky-950/40 hover:bg-sky-100 dark:hover:bg-sky-900/50 border border-sky-200 dark:border-sky-800/80 transition-colors text-left"
              >
                <span className="font-mono-tabular font-bold text-lg text-sky-700 dark:text-cyan-300">
                  +750ml Tumbler
                </span>
                <span className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">
                  Gym / lecture bottle
                </span>
              </button>
            </div>

            <form onSubmit={handleCustomSubmit} className="pt-2 flex flex-col sm:flex-row gap-2.5">
              <div className="flex-1">
                <label htmlFor="custom-water-ml" className="sr-only">
                  Custom Amount (ml)
                </label>
                <input
                  id="custom-water-ml"
                  type="number"
                  min={25}
                  max={3000}
                  value={customMl}
                  onChange={(e) => setCustomMl(e.target.value)}
                  placeholder="Custom amount in ml (e.g. 350)"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-sm font-mono-tabular focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>
              <button
                type="submit"
                className="inline-flex items-center justify-center gap-1.5 px-5 py-2.5 rounded-xl bg-slate-900 dark:bg-cyan-500 hover:bg-slate-800 dark:hover:bg-cyan-400 text-white dark:text-slate-950 text-sm font-semibold transition-colors whitespace-nowrap shrink-0"
              >
                <Plus className="w-4 h-4" />
                <span>Custom Amount</span>
              </button>
            </form>
            {customError && (
              <div role="alert" className="text-xs font-medium text-rose-600 dark:text-rose-400">
                {customError}
              </div>
            )}
          </section>

          {/* Caffeine Offset Calculator */}
          <section
            aria-label="Caffeine Offset Calculator"
            className="rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800 p-6 space-y-4"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h2 className="font-display font-bold text-lg text-slate-900 dark:text-white">
                  Caffeine Offset Calculator
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Each caffeinated drink adds +200ml compensatory water to your target, kept separate from intake.
                </p>
              </div>
              <div className="text-right font-mono-tabular text-sm font-semibold text-amber-600 dark:text-amber-400 whitespace-nowrap shrink-0">
                {caffeineLogs.length} {caffeineLogs.length === 1 ? 'drink' : 'drinks'} · +{caffeineOffsetMl} ml offset
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => onLogCaffeine('coffee', 'Brewed Coffee')}
                className="flex items-center justify-between px-4 py-3 rounded-xl bg-amber-50/70 dark:bg-amber-950/30 hover:bg-amber-100/80 dark:hover:bg-amber-900/40 border border-amber-200/80 dark:border-amber-800/60 transition-colors"
              >
                <span className="flex items-center gap-2.5 text-sm font-semibold text-slate-900 dark:text-white">
                  <Coffee className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                  <span>Log Coffee</span>
                </span>
                <span className="text-xs font-mono-tabular font-semibold text-amber-700 dark:text-amber-300">
                  +200ml target
                </span>
              </button>

              <button
                type="button"
                onClick={() => onLogCaffeine('energy-drink', 'Energy Drink')}
                className="flex items-center justify-between px-4 py-3 rounded-xl bg-amber-50/70 dark:bg-amber-950/30 hover:bg-amber-100/80 dark:hover:bg-amber-900/40 border border-amber-200/80 dark:border-amber-800/60 transition-colors"
              >
                <span className="flex items-center gap-2.5 text-sm font-semibold text-slate-900 dark:text-white">
                  <Zap className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                  <span>Log Energy Drink</span>
                </span>
                <span className="text-xs font-mono-tabular font-semibold text-amber-700 dark:text-amber-300">
                  +200ml target
                </span>
              </button>
            </div>
          </section>
        </div>
      </div>

      {/* Hydration & Caffeine Timeline */}
      <section
        aria-label="Hydration Timeline"
        className="rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800 p-6"
      >
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display font-bold text-lg text-slate-900 dark:text-white">
            Today&apos;s Hydration Timeline
          </h2>
          <span className="text-xs font-mono-tabular text-slate-500 dark:text-slate-400">
            {timeline.length} {timeline.length === 1 ? 'entry' : 'entries'}
          </span>
        </div>

        {timeline.length === 0 ? (
          <div className="py-10 text-center text-sm text-slate-500 dark:text-slate-400">
            No drinks logged yet today. Tap +250ml or +500ml above to start your streak.
          </div>
        ) : (
          <ul className="divide-y divide-slate-100 dark:divide-slate-800/80">
            {timeline.map((item) => (
              <li key={item.id} className="py-3 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3 min-w-0">
                  {item.kind === 'water' ? (
                    <Droplets className="w-4 h-4 text-sky-600 dark:text-cyan-400 shrink-0" />
                  ) : (
                    <Coffee className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
                  )}
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-slate-900 dark:text-white truncate">
                      {item.label}
                    </div>
                    <div className="text-xs font-mono-tabular text-slate-500 dark:text-slate-400">
                      {formatTime(item.timestamp)}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <span
                    className={`text-sm font-mono-tabular font-semibold ${
                      item.kind === 'water'
                        ? 'text-sky-700 dark:text-cyan-300'
                        : 'text-amber-600 dark:text-amber-400'
                    }`}
                  >
                    {item.amountText}
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      item.kind === 'water'
                        ? onDeleteWaterLog(item.id)
                        : onDeleteCaffeineLog(item.id)
                    }
                    aria-label={`Remove ${item.label} entry`}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
};
