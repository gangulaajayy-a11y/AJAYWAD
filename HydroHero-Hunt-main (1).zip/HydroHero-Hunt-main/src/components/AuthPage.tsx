import React, { useState } from 'react';
import { ArrowLeft, ArrowRight, ShieldCheck } from 'lucide-react';
import { BrandLockup } from './Logo';

interface AuthPageProps {
  onBackToLanding: () => void;
  onSignUpStart: (creds: { name: string; email: string; password: string }) => void;
  onDemoLogin: () => void;
  onLoginExisting: (email: string) => void;
}

export const AuthPage: React.FC<AuthPageProps> = ({
  onBackToLanding,
  onSignUpStart,
  onDemoLogin,
  onLoginExisting,
}) => {
  const [mode, setMode] = useState<'signup' | 'login'>('signup');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const trimmedEmail = email.trim();
    if (!trimmedEmail || !trimmedEmail.includes('@')) {
      setError('Please enter a valid email address.');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }

    if (mode === 'signup') {
      if (!name.trim()) {
        setError('Please enter your full name.');
        return;
      }
      onSignUpStart({ name: name.trim(), email: trimmedEmail, password });
    } else {
      onLoginExisting(trimmedEmail);
    }
  };

  return (
    <div className="min-h-screen bg-[#f4f9ff] dark:bg-[#070e1d] text-slate-900 dark:text-slate-100 flex flex-col justify-center px-4 py-12">
      <div className="max-w-md w-full mx-auto">
        <button
          type="button"
          onClick={onBackToLanding}
          className="inline-flex items-center gap-1.5 text-sm font-medium text-slate-600 dark:text-slate-300 hover:text-sky-600 dark:hover:text-cyan-400 mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to overview</span>
        </button>

        <div className="rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800 p-8 shadow-sm">
          <div className="mb-6">
            <BrandLockup showSubtitle />
            <h1 className="font-display font-bold text-2xl text-slate-900 dark:text-white mt-5">
              {mode === 'signup' ? 'Create your HydroHero account' : 'Welcome back'}
            </h1>
            <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
              {mode === 'signup'
                ? 'Set up your profile and calculate your personalized daily hydration goal.'
                : 'Sign in to continue your squad hydration streak.'}
            </p>
          </div>

          {/* Mode Tabs */}
          <div className="grid grid-cols-2 gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-900 mb-6">
            <button
              type="button"
              onClick={() => {
                setMode('signup');
                setError('');
              }}
              className={`py-2 text-sm font-semibold rounded-lg transition-colors ${
                mode === 'signup'
                  ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Sign Up
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setError('');
              }}
              className={`py-2 text-sm font-semibold rounded-lg transition-colors ${
                mode === 'login'
                  ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Sign In
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4" noValidate>
            {mode === 'signup' && (
              <div>
                <label htmlFor="auth-name" className="block text-sm font-medium text-slate-700 dark:text-slate-200 mb-1.5">
                  Full Name
                </label>
                <input
                  id="auth-name"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Priya Sharma"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>
            )}

            <div>
              <label htmlFor="auth-email" className="block text-sm font-medium text-slate-700 dark:text-slate-200 mb-1.5">
                Email Address
              </label>
              <input
                id="auth-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@campus.edu"
                className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>

            <div>
              <label htmlFor="auth-password" className="block text-sm font-medium text-slate-700 dark:text-slate-200 mb-1.5">
                Password
              </label>
              <input
                id="auth-password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Minimum 6 characters"
                className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>

            {error && (
              <div role="alert" className="text-xs font-medium text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 rounded-xl px-3.5 py-2.5">
                {error}
              </div>
            )}

            <button
              type="submit"
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-sm font-semibold transition-colors"
            >
              <span>{mode === 'signup' ? 'Continue to Hydration Setup' : 'Sign In to Dashboard'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          <div className="mt-6 pt-5 border-t border-slate-200 dark:border-slate-800 space-y-3">
            <button
              type="button"
              onClick={onDemoLogin}
              className="w-full py-2.5 px-4 rounded-xl border border-slate-300 dark:border-slate-700 hover:border-sky-500 dark:hover:border-cyan-400 text-sm font-semibold text-slate-800 dark:text-slate-100 transition-colors"
            >
              Instant Demo Account (Aarav Mehta · 70 kg)
            </button>
            <div className="flex items-center justify-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Local browser persistence enabled for instant demo</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
