import React from 'react';
import { ArrowDown, ArrowUp, Award, Crown, Medal, Sparkles } from 'lucide-react';
import type { RankedTeam, UserProfile } from '../types/hydration';

interface LeaderboardPageProps {
  rankedTeams: RankedTeam[];
  user: UserProfile;
  overtakeBanner: string | null;
  onDismissBanner: () => void;
}

export const LeaderboardPage: React.FC<LeaderboardPageProps> = ({
  rankedTeams,
  user,
  overtakeBanner,
  onDismissBanner,
}) => {
  const topThree = rankedTeams.slice(0, 3);
  // Display podium as [#2, #1, #3] on desktop
  const podiumOrder =
    topThree.length >= 3 ? [topThree[1], topThree[0], topThree[2]] : topThree;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display font-bold text-2xl sm:text-3xl tracking-tight text-slate-900 dark:text-white">
          HydroHero Team Leaderboard
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
          Scored fairly via capped completion: TeamScore = (Sum of MIN(Intake / Goal, 1) / Team Size) × 100
        </p>
      </div>

      {overtakeBanner && (
        <div
          role="status"
          className="rounded-2xl bg-gradient-to-r from-sky-600 to-cyan-500 text-white p-4 flex items-center justify-between gap-4 shadow-md"
        >
          <div className="flex items-center gap-3">
            <Sparkles className="w-5 h-5 shrink-0" />
            <span className="font-semibold text-sm">{overtakeBanner}</span>
          </div>
          <button
            type="button"
            onClick={onDismissBanner}
            className="text-xs font-semibold underline underline-offset-4 shrink-0"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Top 3 Podium */}
      <section aria-label="Top Three Podium" className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end pt-2">
        {podiumOrder.map((team) => {
          const isFirst = team.rank === 1;
          const isUserTeam = team.id === user.teamId;
          return (
            <div
              key={team.id}
              className={`rounded-2xl p-6 border transition-transform duration-200 ${
                isFirst
                  ? 'bg-[#0b1730] text-white border-sky-500/70 md:pb-10 shadow-lg'
                  : 'bg-white dark:bg-[#0d1930] border-slate-200 dark:border-slate-800'
              } ${isUserTeam && !isFirst ? 'ring-2 ring-sky-500/60' : ''}`}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  {team.rank === 1 ? (
                    <Crown className="w-5 h-5 text-amber-400" />
                  ) : team.rank === 2 ? (
                    <Medal className="w-5 h-5 text-slate-400" />
                  ) : (
                    <Award className="w-5 h-5 text-amber-600" />
                  )}
                  <span className="font-mono-tabular font-bold text-sm">
                    Rank #{team.rank}
                  </span>
                </div>
                {isUserTeam && (
                  <span className="text-xs font-semibold text-cyan-400">
                    Your Squad
                  </span>
                )}
              </div>

              <h2 className="font-display font-bold text-xl truncate">{team.name}</h2>

              <div className="mt-4 flex items-baseline justify-between">
                <div className="text-3xl font-display font-bold font-mono-tabular">
                  {team.teamScore.toFixed(1)}%
                </div>
                <div className={`text-xs font-mono-tabular ${isFirst ? 'text-slate-300' : 'text-slate-500 dark:text-slate-400'}`}>
                  {(team.totalIntakeMl / 1000).toFixed(2)} L consumed
                </div>
              </div>

              <div className={`mt-3 h-2 w-full rounded-full overflow-hidden ${isFirst ? 'bg-slate-800' : 'bg-slate-100 dark:bg-slate-800'}`}>
                <div
                  className="h-full rounded-full bg-gradient-to-r from-sky-500 to-cyan-400 transition-all duration-300"
                  style={{ width: `${Math.min(100, team.teamScore)}%` }}
                />
              </div>
            </div>
          );
        })}
      </section>

      {/* Full Leaderboard Table */}
      <section className="rounded-2xl bg-white dark:bg-[#0d1930] border border-slate-200 dark:border-slate-800 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <h2 className="font-display font-bold text-lg text-slate-900 dark:text-white">
            All Squad Rankings
          </h2>
          <span className="text-xs text-slate-500 dark:text-slate-400">
            Updates instantaneously on every sip logged
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-500 dark:text-slate-400">
                <th className="py-3.5 px-5">Rank</th>
                <th className="py-3.5 px-5">Team Name</th>
                <th className="py-3.5 px-5 text-right">Active Members</th>
                <th className="py-3.5 px-5 text-right">Total Consumed</th>
                <th className="py-3.5 px-5">Target Progress</th>
                <th className="py-3.5 px-5 text-right">Team Score</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200/70 dark:divide-slate-800/70 text-sm">
              {rankedTeams.map((team) => {
                const isUserTeam = team.id === user.teamId;
                const rankDelta =
                  team.previousRank !== undefined ? team.previousRank - team.rank : 0;
                const targetRatio =
                  team.totalGoalMl > 0
                    ? Math.min(100, Math.round((team.totalIntakeMl / team.totalGoalMl) * 100))
                    : 0;

                return (
                  <tr
                    key={team.id}
                    className={
                      isUserTeam
                        ? 'bg-sky-50/70 dark:bg-sky-950/30 font-medium'
                        : 'hover:bg-slate-50 dark:hover:bg-slate-900/40 transition-colors'
                    }
                  >
                    <td className="py-4 px-5 font-mono-tabular font-bold text-slate-900 dark:text-white">
                      <div className="flex items-center gap-2">
                        <span>#{team.rank}</span>
                        {rankDelta > 0 && (
                          <span className="inline-flex items-center text-xs text-emerald-600 dark:text-emerald-400">
                            <ArrowUp className="w-3.5 h-3.5" />
                            {rankDelta}
                          </span>
                        )}
                        {rankDelta < 0 && (
                          <span className="inline-flex items-center text-xs text-rose-600 dark:text-rose-400">
                            <ArrowDown className="w-3.5 h-3.5" />
                            {Math.abs(rankDelta)}
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="py-4 px-5 text-slate-900 dark:text-white">
                      <span className="font-semibold">{team.name}</span>
                      {isUserTeam && (
                        <span className="ml-2 text-xs font-semibold text-sky-600 dark:text-cyan-400">
                          (Your Squad)
                        </span>
                      )}
                    </td>
                    <td className="py-4 px-5 text-right font-mono-tabular text-slate-600 dark:text-slate-300">
                      {team.activeMembersCount}/{team.members.length}
                    </td>
                    <td className="py-4 px-5 text-right font-mono-tabular text-slate-600 dark:text-slate-300">
                      {(team.totalIntakeMl / 1000).toFixed(2)} L
                    </td>
                    <td className="py-4 px-5 min-w-[160px]">
                      <div className="flex items-center gap-2.5">
                        <div className="flex-1 h-2 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
                          <div
                            className="h-full rounded-full bg-gradient-to-r from-sky-500 to-cyan-400 transition-all duration-300"
                            style={{ width: `${targetRatio}%` }}
                          />
                        </div>
                        <span className="font-mono-tabular text-xs text-slate-600 dark:text-slate-300 w-10 text-right">
                          {targetRatio}%
                        </span>
                      </div>
                    </td>
                    <td className="py-4 px-5 text-right font-mono-tabular font-bold text-sky-700 dark:text-cyan-300">
                      {team.teamScore.toFixed(1)}%
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
