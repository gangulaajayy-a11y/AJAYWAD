import React, { useId } from 'react';

interface LogoProps {
  compact?: boolean;
  showSubtitle?: boolean;
}

export const SipStreakMark: React.FC<{ className?: string }> = ({ className = 'w-8 h-8' }) => {
  const gradId = `sipstreak-drop-${useId()}`;
  return (
    <svg
      viewBox="0 0 40 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id={gradId} x1="8" y1="4" x2="32" y2="36" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#06B6D4" />
          <stop offset="55%" stopColor="#0284C7" />
          <stop offset="100%" stopColor="#1D4ED8" />
        </linearGradient>
      </defs>
      {/* Droplet Silhouette */}
      <path
        d="M20 3.5C20 3.5 8.5 16.2 8.5 24.5C8.5 30.85 13.65 36 20 36C26.35 36 31.5 30.85 31.5 24.5C31.5 16.2 20 3.5 20 3.5Z"
        fill={`url(#${gradId})`}
      />
    {/* Crisp inner droplet highlight */}
    <path
      d="M14.2 23.5C14.2 26.8 16.4 29.8 19.2 30.6"
      stroke="rgba(255,255,255,0.45)"
      strokeWidth="1.75"
      strokeLinecap="round"
    />
      {/* Lightning Bolt */}
      <path
        d="M21.4 12.5L15.6 22H20.3L18.8 29.5L24.8 19.6H20L21.4 12.5Z"
        fill="#FFFFFF"
        stroke="#0F172A"
        strokeOpacity="0.12"
        strokeWidth="0.6"
        strokeLinejoin="round"
      />
    </svg>
  );
};

export const BrandLockup: React.FC<LogoProps> = ({ compact = false, showSubtitle = false }) => {
  return (
    <div className="flex items-center gap-2.5 shrink-0">
      <SipStreakMark className={compact ? 'w-7 h-7' : 'w-8 h-8'} />
      <div className="flex flex-col leading-none">
        <span className="font-display font-bold tracking-tight text-slate-900 dark:text-white text-lg whitespace-nowrap">
          SIPSTREAK
        </span>
        {showSubtitle && (
          <span className="text-[10px] font-semibold tracking-[0.14em] text-sky-600 dark:text-cyan-400 uppercase whitespace-nowrap mt-0.5">
            HYDROHERO HUNT
          </span>
        )}
      </div>
    </div>
  );
};
