import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Info, LocateFixed, MapPin } from 'lucide-react';
import { SAMPLE_CAMPUS_STATIONS } from '../data/seedData';
import type { CampusStation } from '../types/hydration';
import { calculateDistanceMeters } from '../utils/hydrationMath';

const CAMPUS_CENTER = { lat: 37.4275, lng: -122.1697 };

export const CampusMapPage: React.FC = () => {
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersRef = useRef<Map<string, L.CircleMarker>>(new Map());

  const [userCoords, setUserCoords] = useState<{ lat: number; lng: number }>(CAMPUS_CENTER);
  const [selectedStation, setSelectedStation] = useState<CampusStation>(SAMPLE_CAMPUS_STATIONS[0]);
  const [locateMessage, setLocateMessage] = useState<string>(
    'Centered on sample campus quad. Click "Locate Nearby Stations" to sort by proximity.',
  );

  useEffect(() => {
    if (!mapContainerRef.current || mapInstanceRef.current) return;

    const map = L.map(mapContainerRef.current, {
      center: [CAMPUS_CENTER.lat, CAMPUS_CENTER.lng],
      zoom: 16,
      zoomControl: true,
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors',
      maxZoom: 19,
    }).addTo(map);

    SAMPLE_CAMPUS_STATIONS.forEach((station) => {
      const color =
        station.status === 'operational'
          ? '#0284c7'
          : station.status === 'busy'
            ? '#d97706'
            : '#dc2626';

      const marker = L.circleMarker([station.lat, station.lng], {
        radius: 10,
        fillColor: color,
        color: '#ffffff',
        weight: 2.5,
        opacity: 1,
        fillOpacity: 0.92,
      }).addTo(map);

      marker.bindPopup(
        `<div style="font-family: sans-serif; min-width: 190px;">
          <div style="font-weight: 700; font-size: 13px; margin-bottom: 2px;">${station.name}</div>
          <div style="font-size: 11px; color: #475569; margin-bottom: 6px;">${station.building} · ${station.floor}</div>
          <div style="font-size: 11px; margin-bottom: 2px;"><strong>Water Status:</strong> ${station.waterQuality}</div>
          <div style="font-size: 11px; margin-bottom: 4px;"><strong>Availability:</strong> ${station.availability}</div>
          <div style="font-size: 10px; color: #0284c7; font-weight: 600;">Sample Demo Station</div>
        </div>`,
      );

      marker.on('click', () => {
        setSelectedStation(station);
      });

      markersRef.current.set(station.id, marker);
    });

    mapInstanceRef.current = map;

    return () => {
      map.remove();
      mapInstanceRef.current = null;
      markersRef.current.clear();
    };
  }, []);

  const focusStation = (station: CampusStation) => {
    setSelectedStation(station);
    const map = mapInstanceRef.current;
    const marker = markersRef.current.get(station.id);
    if (map) {
      map.setView([station.lat, station.lng], 17, { animate: true });
    }
    if (marker) {
      marker.openPopup();
    }
  };

  const handleLocateNearby = () => {
    if (!navigator.geolocation) {
      setUserCoords(CAMPUS_CENTER);
      setLocateMessage('Browser geolocation unavailable; showing nearest sample stations from campus center.');
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const next = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        setUserCoords(next);
        setLocateMessage('Sorted sample stations by distance from your location (campus demo coordinates).');
      },
      () => {
        setUserCoords(CAMPUS_CENTER);
        setLocateMessage('Location access declined; sorted sample stations from Central Library Quad.');
      },
      { timeout: 3500 },
    );
  };

  const sortedStations = [...SAMPLE_CAMPUS_STATIONS]
    .map((station) => ({
      ...station,
      distanceMeters: calculateDistanceMeters(
        userCoords.lat,
        userCoords.lng,
        station.lat,
        station.lng,
      ),
    }))
    .sort((a, b) => a.distanceMeters - b.distanceMeters);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="font-display font-bold text-2xl sm:text-3xl tracking-tight text-slate-900 dark:text-white">
            Campus Water Refill Map
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
            Interactive OpenStreetMap & Leaflet locator for hydration stations across campus.
          </p>
        </div>

        <button
          type="button"
          onClick={handleLocateNearby}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-sm font-semibold transition-colors self-start sm:self-auto whitespace-nowrap shrink-0"
        >
          <LocateFixed className="w-4 h-4" />
          <span>Locate Nearby Stations</span>
        </button>
      </div>

      {/* Sample Demo Data Notice */}
      <div className="rounded-xl bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800/80 px-4 py-3 flex items-start gap-3 text-xs text-sky-900 dark:text-cyan-200">
        <Info className="w-4 h-4 shrink-0 mt-0.5 text-sky-600 dark:text-cyan-400" />
        <div>
          <strong>Sample Campus Demo Data:</strong> Displayed water refill markers, quality checks, and availability statuses are illustrative sample data for demonstration rather than verified real-world municipal or university facilities. {locateMessage}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Map Container */}
        <div className="lg:col-span-7 rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-900 min-h-[420px]">
          <div
            ref={mapContainerRef}
            data-testid="campus-leaflet-map"
            className="w-full h-[420px] lg:h-full min-h-[420px]"
            aria-label="Interactive campus water refill stations map"
          />
        </div>

        {/* Station Directory */}
        <div className="lg:col-span-5 space-y-3">
          {sortedStations.map((station) => {
            const isSelected = selectedStation.id === station.id;
            const statusText =
              station.status === 'operational'
                ? 'Operational'
                : station.status === 'busy'
                  ? 'High Traffic'
                  : 'Maintenance';
            const statusColor =
              station.status === 'operational'
                ? 'text-emerald-600 dark:text-emerald-400'
                : station.status === 'busy'
                  ? 'text-amber-600 dark:text-amber-400'
                  : 'text-rose-600 dark:text-rose-400';

            return (
              <button
                key={station.id}
                type="button"
                onClick={() => focusStation(station)}
                className={`w-full text-left p-4 rounded-2xl border transition-colors ${
                  isSelected
                    ? 'bg-sky-50/70 dark:bg-sky-950/30 border-sky-500 dark:border-cyan-400'
                    : 'bg-white dark:bg-[#0d1930] border-slate-200 dark:border-slate-800 hover:border-sky-300 dark:hover:border-slate-700'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-start gap-2.5">
                    <MapPin className="w-4 h-4 text-sky-600 dark:text-cyan-400 shrink-0 mt-1" />
                    <div>
                      <div className="font-display font-bold text-sm text-slate-900 dark:text-white">
                        {station.name}
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">
                        {station.building} · {station.floor}
                      </div>
                    </div>
                  </div>
                  <span className="font-mono-tabular text-xs text-slate-500 dark:text-slate-400 shrink-0">
                    {station.distanceMeters < 1000
                      ? `${station.distanceMeters} m`
                      : `${(station.distanceMeters / 1000).toFixed(1)} km`}
                  </span>
                </div>

                <div className="mt-2.5 pt-2.5 border-t border-slate-100 dark:border-slate-800/80 text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className={`font-semibold ${statusColor}`}>{statusText}</span>
                    <span className="text-slate-500 dark:text-slate-400">{station.temperature} · Sample Data</span>
                  </div>
                  <div className="text-slate-600 dark:text-slate-300">{station.waterQuality}</div>
                  <div className="text-slate-500 dark:text-slate-400">{station.availability}</div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
