import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateAnalyticsSummary,
  calculateCaffeineOffset,
  calculateDailyTarget,
  calculateDistanceMeters,
  calculateEffectiveTarget,
  calculateMemberCompletion,
  calculateTeamScore,
  computePlantStatus,
  isWithinReminderHours,
  rankTeams,
  validateSquadSizeLimit,
} from './hydrationMath';
import type { TeamSquad } from '../types/hydration';

test('calculateDailyTarget uses WeightKg * 35 formula', () => {
  assert.equal(calculateDailyTarget(70), 2450);
  assert.equal(calculateDailyTarget(60), 2100);
  assert.equal(calculateDailyTarget(82), 2870);
});

test('caffeine offset adds +200ml per caffeinated drink', () => {
  assert.equal(calculateCaffeineOffset(0), 0);
  assert.equal(calculateCaffeineOffset(1), 200);
  assert.equal(calculateCaffeineOffset(3), 600);
  assert.equal(calculateEffectiveTarget(2450, 2), 2850);
});

test('calculateMemberCompletion caps individual completion at 1.0', () => {
  assert.equal(calculateMemberCompletion(1225, 2450), 0.5);
  assert.equal(calculateMemberCompletion(2450, 2450), 1);
  assert.equal(calculateMemberCompletion(5000, 2450), 1);
  assert.equal(calculateMemberCompletion(-100, 2450), 0);
});

test('calculateTeamScore prevents heavy drinker from carrying entire squad', () => {
  const score = calculateTeamScore([
    { intakeMl: 8000, goalMl: 2000 }, // capped at 1.0
    { intakeMl: 1000, goalMl: 2000 }, // 0.5
    { intakeMl: 0, goalMl: 2000 }, // 0.0
    { intakeMl: 1000, goalMl: 2000 }, // 0.5
  ]);
  // (1.0 + 0.5 + 0.0 + 0.5) / 4 * 100 = 50.0
  assert.equal(score, 50.0);
});

test('rankTeams orders squads by capped teamScore descending and tracks rank', () => {
  const squads: TeamSquad[] = [
    {
      id: 't1',
      name: 'Alpha',
      inviteCode: 'ALP',
      description: '',
      maxMembers: 4,
      members: [
        { id: '1', name: 'A', role: 'M', avatarInitials: 'A', avatarColor: '#0284c7', intakeMl: 1000, goalMl: 2000, streakDays: 1 },
        { id: '2', name: 'B', role: 'M', avatarInitials: 'B', avatarColor: '#0284c7', intakeMl: 1000, goalMl: 2000, streakDays: 1 },
        { id: '3', name: 'C', role: 'M', avatarInitials: 'C', avatarColor: '#0284c7', intakeMl: 1000, goalMl: 2000, streakDays: 1 },
        { id: '4', name: 'D', role: 'M', avatarInitials: 'D', avatarColor: '#0284c7', intakeMl: 1000, goalMl: 2000, streakDays: 1 },
      ],
    },
    {
      id: 't2',
      name: 'Beta',
      inviteCode: 'BET',
      description: '',
      maxMembers: 4,
      members: [
        { id: '5', name: 'E', role: 'M', avatarInitials: 'E', avatarColor: '#06b6d4', intakeMl: 2000, goalMl: 2000, streakDays: 2 },
        { id: '6', name: 'F', role: 'M', avatarInitials: 'F', avatarColor: '#06b6d4', intakeMl: 2000, goalMl: 2000, streakDays: 2 },
        { id: '7', name: 'G', role: 'M', avatarInitials: 'G', avatarColor: '#06b6d4', intakeMl: 1500, goalMl: 2000, streakDays: 2 },
        { id: '8', name: 'H', role: 'M', avatarInitials: 'H', avatarColor: '#06b6d4', intakeMl: 1500, goalMl: 2000, streakDays: 2 },
      ],
    },
  ];

  const ranked = rankTeams(squads, { t1: 1, t2: 2 });
  assert.equal(ranked[0].id, 't2');
  assert.equal(ranked[0].rank, 1);
  assert.equal(ranked[0].previousRank, 2);
  assert.equal(ranked[0].teamScore, 87.5);
  assert.equal(ranked[1].id, 't1');
  assert.equal(ranked[1].rank, 2);
});

test('validateSquadSizeLimit enforces 4 to 8 members', () => {
  assert.equal(validateSquadSizeLimit(3).valid, false);
  assert.equal(validateSquadSizeLimit(4).valid, true);
  assert.equal(validateSquadSizeLimit(8).valid, true);
  assert.equal(validateSquadSizeLimit(9).valid, false);
});

test('computePlantStatus transitions through 5 growth stages and handles wilting', () => {
  assert.equal(computePlantStatus(100, 2450, 1).stage, 'seed');
  assert.equal(computePlantStatus(600, 2450, 1).stage, 'sprout');
  assert.equal(computePlantStatus(1300, 2450, 2).stage, 'growing');
  assert.equal(computePlantStatus(2100, 2450, 2).stage, 'healthy');
  assert.equal(computePlantStatus(2450, 2450, 5).stage, 'blooming');

  const wilted = computePlantStatus(1200, 2450, 2, true);
  assert.equal(wilted.isWilted, true);
});

test('calculateAnalyticsSummary updates today intake and calculates weekly average', () => {
  const history = [
    { day: 'Mon', date: '2026-11-12', intakeMl: 2000, goalMl: 2450, teamAvgMl: 1900, caffeineCount: 1 },
    { day: 'Tue', date: '2026-11-13', intakeMl: 2500, goalMl: 2450, teamAvgMl: 2100, caffeineCount: 0 },
    { day: 'Today', date: '2026-11-18', intakeMl: 0, goalMl: 2450, teamAvgMl: 2000, caffeineCount: 0 },
  ];
  const summary = calculateAnalyticsSummary(history, 3000, 2450);
  assert.equal(summary.weeklyAverageMl, 2500);
  assert.equal(summary.bestDay.day, 'Today');
  assert.equal(summary.daysHitGoal, 2);
});

test('distance and daytime reminder windows work accurately', () => {
  const dist = calculateDistanceMeters(37.4275, -122.1697, 37.4285, -122.1697);
  assert.ok(dist > 90 && dist < 130);
  assert.equal(isWithinReminderHours(10, 8, 20), true);
  assert.equal(isWithinReminderHours(22, 8, 20), false);
});
