import type { AppState } from '../types/hydration';
import { createInitialState } from '../data/seedData';

const STORAGE_KEY = 'sipstreak_hydrohero_state_v1';

export function loadAppState(): AppState {
  if (typeof window === 'undefined') {
    return createInitialState();
  }
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return createInitialState();
    const parsed = JSON.parse(raw) as Partial<AppState>;
    const fallback = createInitialState();
    return {
      ...fallback,
      ...parsed,
      user: { ...fallback.user, ...(parsed.user ?? {}) },
      reminders: { ...fallback.reminders, ...(parsed.reminders ?? {}) },
      waterLogs: Array.isArray(parsed.waterLogs) ? parsed.waterLogs : fallback.waterLogs,
      caffeineLogs: Array.isArray(parsed.caffeineLogs) ? parsed.caffeineLogs : fallback.caffeineLogs,
      teams: Array.isArray(parsed.teams) && parsed.teams.length > 0 ? parsed.teams : fallback.teams,
      history: Array.isArray(parsed.history) && parsed.history.length > 0 ? parsed.history : fallback.history,
    };
  } catch {
    return createInitialState();
  }
}

export function saveAppState(state: AppState): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // Ignore storage quota errors cleanly
  }
}

export function resetAppState(): AppState {
  const fresh = createInitialState();
  saveAppState(fresh);
  return fresh;
}
