import type {
  DailyHistoryEntry,
  PlantStatus,
  RankedTeam,
  TeamMember,
  TeamSquad,
} from '../types/hydration';

export const CAFFEINE_OFFSET_PER_DRINK_ML = 200;
export const MIN_SQUAD_SIZE = 4;
export const MAX_SQUAD_SIZE = 8;

/**
 * TargetMl = WeightKg * 35
 */
export function calculateDailyTarget(weightKg: number): number {
  const safeWeight = Number.isFinite(weightKg) && weightKg > 0 ? weightKg : 70;
  return Math.round(safeWeight * 35);
}

/**
 * Each caffeine drink adds +200ml compensatory water requirement.
 */
export function calculateCaffeineOffset(caffeineDrinkCount: number): number {
  const safeCount = Math.max(0, Math.floor(caffeineDrinkCount));
  return safeCount * CAFFEINE_OFFSET_PER_DRINK_ML;
}

export function calculateEffectiveTarget(
  baseGoalMl: number,
  caffeineDrinkCount: number,
): number {
  return Math.max(500, Math.round(baseGoalMl)) + calculateCaffeineOffset(caffeineDrinkCount);
}

/**
 * MemberCompletion = MIN(MemberIntake / MemberGoal, 1)
 */
export function calculateMemberCompletion(intakeMl: number, goalMl: number): number {
  if (goalMl <= 0) return 0;
  const ratio = Math.max(0, intakeMl) / goalMl;
  return Math.min(ratio, 1);
}

/**
 * TeamScore = (Sum of each member's capped hydration completion percentage / Team Size) * 100
 */
export function calculateTeamScore(
  members: Array<Pick<TeamMember, 'intakeMl' | 'goalMl'>>,
): number {
  if (members.length === 0) return 0;
  const sumCompletion = members.reduce(
    (acc, member) => acc + calculateMemberCompletion(member.intakeMl, member.goalMl),
    0,
  );
  return Number(((sumCompletion / members.length) * 100).toFixed(1));
}

export function rankTeams(
  teams: TeamSquad[],
  previousRanks?: Record<string, number>,
): RankedTeam[] {
  const enriched = teams.map((team) => {
    const teamScore = calculateTeamScore(team.members);
    const totalIntakeMl = team.members.reduce((sum, m) => sum + Math.max(0, m.intakeMl), 0);
    const totalGoalMl = team.members.reduce((sum, m) => sum + Math.max(1, m.goalMl), 0);
    const activeMembersCount = team.members.filter((m) => m.intakeMl > 0).length;

    return {
      ...team,
      teamScore,
      totalIntakeMl,
      totalGoalMl,
      activeMembersCount,
      rank: 0,
      previousRank: previousRanks?.[team.id],
    };
  });

  enriched.sort((a, b) => {
    if (b.teamScore !== a.teamScore) return b.teamScore - a.teamScore;
    return b.totalIntakeMl - a.totalIntakeMl;
  });

  return enriched.map((team, idx) => ({
    ...team,
    rank: idx + 1,
  }));
}

export function validateSquadSizeLimit(maxMembers: number): {
  valid: boolean;
  clamped: number;
  error?: string;
} {
  if (!Number.isFinite(maxMembers)) {
    return {
      valid: false,
      clamped: 6,
      error: 'Squad size must be a number between 4 and 8.',
    };
  }
  const rounded = Math.round(maxMembers);
  if (rounded < MIN_SQUAD_SIZE || rounded > MAX_SQUAD_SIZE) {
    return {
      valid: false,
      clamped: Math.min(MAX_SQUAD_SIZE, Math.max(MIN_SQUAD_SIZE, rounded)),
      error: `Squad size must be between ${MIN_SQUAD_SIZE} and ${MAX_SQUAD_SIZE} members.`,
    };
  }
  return { valid: true, clamped: rounded };
}

export function computePlantStatus(
  intakeMl: number,
  effectiveGoalMl: number,
  streakDays: number,
  simulateNeglect = false,
): PlantStatus {
  const progress = effectiveGoalMl > 0 ? intakeMl / effectiveGoalMl : 0;

  if (simulateNeglect || (progress < 0.25 && streakDays === 0)) {
    return {
      stage: progress < 0.15 ? 'seed' : 'sprout',
      stageLabel: simulateNeglect ? 'Wilting Sprout' : 'Thirsty Seed',
      stageIndex: progress < 0.15 ? 1 : 2,
      isWilted: true,
      healthPercent: Math.max(18, Math.round(progress * 100)),
      message:
        'Your companion is drooping from low hydration. Log a +250ml cup to restore leaf turgor.',
      nextMilestoneText: 'Reach 35% of today’s target to perk up leaves',
    };
  }

  if (progress >= 1 && streakDays >= 4) {
    return {
      stage: 'blooming',
      stageLabel: 'Fully Grown Botanical',
      stageIndex: 5,
      isWilted: false,
      healthPercent: 100,
      message:
        'Peak hydration unlocked! Consistent daily goals brought your HydroFern into full bloom.',
      nextMilestoneText: 'Maintain your streak to keep full canopy radiance',
    };
  }

  if (progress >= 0.8 || (progress >= 0.65 && streakDays >= 3)) {
    return {
      stage: 'healthy',
      stageLabel: 'Healthy Plant',
      stageIndex: 4,
      isWilted: false,
      healthPercent: Math.min(96, Math.round(70 + progress * 25)),
      message:
        'Deep emerald foliage and steady sap flow. One final glass completes today’s bloom.',
      nextMilestoneText: 'Hit 100% today with a 4+ day streak for Full Bloom',
    };
  }

  if (progress >= 0.45) {
    return {
      stage: 'growing',
      stageLabel: 'Growing Plant',
      stageIndex: 3,
      isWilted: false,
      healthPercent: Math.round(52 + progress * 30),
      message:
        'New shoots are unfurling cleanly. Keep sipping steadily through the afternoon.',
      nextMilestoneText: 'Reach 80% of daily target for Healthy Plant stage',
    };
  }

  if (progress >= 0.18) {
    return {
      stage: 'sprout',
      stageLabel: 'Small Sprout',
      stageIndex: 2,
      isWilted: false,
      healthPercent: Math.round(35 + progress * 40),
      message:
        'First cotyledon leaves emerged! Add another bottle to strengthen the stem.',
      nextMilestoneText: 'Reach 45% of daily target for Growing Plant stage',
    };
  }

  return {
    stage: 'seed',
    stageLabel: 'Germinating Seed',
    stageIndex: 1,
    isWilted: false,
    healthPercent: Math.max(25, Math.round(25 + progress * 50)),
    message:
      'Your seed is tucked into damp soil, waiting for your morning hydration log.',
    nextMilestoneText: 'Reach 18% of daily target to sprout',
  };
}

export function calculateAnalyticsSummary(
  history: DailyHistoryEntry[],
  todayIntakeMl: number,
  todayGoalMl: number,
) {
  const combined = history.map((entry, idx) =>
    idx === history.length - 1
      ? { ...entry, intakeMl: todayIntakeMl, goalMl: todayGoalMl }
      : entry,
  );

  const total = combined.reduce((s, d) => s + d.intakeMl, 0);
  const weeklyAverageMl = combined.length > 0 ? Math.round(total / combined.length) : 0;

  const bestDay = combined.reduce(
    (best, cur) => (cur.intakeMl > best.intakeMl ? cur : best),
    combined[0] ?? { day: 'Today', date: '', intakeMl: 0, goalMl: todayGoalMl, teamAvgMl: 0, caffeineCount: 0 },
  );

  const daysHitGoal = combined.filter((d) => d.intakeMl >= d.goalMl).length;

  return {
    series: combined,
    weeklyAverageMl,
    bestDay,
    daysHitGoal,
  };
}

export function calculateDistanceMeters(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number,
): number {
  const R = 6371000;
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}

export function isWithinReminderHours(
  currentHour: number,
  startHour: number,
  endHour: number,
): boolean {
  if (startHour <= endHour) {
    return currentHour >= startHour && currentHour <= endHour;
  }
  return currentHour >= startHour || currentHour <= endHour;
}
