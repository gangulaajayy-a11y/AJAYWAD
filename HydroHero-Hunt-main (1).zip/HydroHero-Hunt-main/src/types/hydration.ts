export type AppView =
  | 'landing'
  | 'auth'
  | 'onboarding'
  | 'dashboard'
  | 'squads'
  | 'leaderboard'
  | 'analytics'
  | 'plant'
  | 'map'
  | 'profile';

export type ThemeMode = 'light' | 'dark';

export type ActivityLevel = 'sedentary' | 'moderate' | 'active' | 'athlete';

export type GenderOption = 'prefer-not-to-say' | 'female' | 'male' | 'non-binary';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  age: number;
  weightKg: number;
  gender?: GenderOption;
  activityLevel: ActivityLevel;
  baseGoalMl: number; // WeightKg * 35
  teamId: string;
  streakDays: number;
  longestStreakDays: number;
  onboarded: boolean;
}

export interface WaterLog {
  id: string;
  amountMl: number;
  label: string;
  timestamp: string; // ISO string
  source?: 'cup' | 'bottle' | 'tumbler' | 'custom' | 'qr';
}

export interface CaffeineLog {
  id: string;
  drinkType: 'coffee' | 'energy-drink';
  label: string;
  offsetMl: number; // +200ml per drink
  timestamp: string;
}

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  avatarInitials: string;
  avatarColor: string;
  intakeMl: number;
  goalMl: number;
  streakDays: number;
  isCurrentUser?: boolean;
}

export interface TeamSquad {
  id: string;
  name: string;
  inviteCode: string;
  description: string;
  maxMembers: number; // 4 to 8
  members: TeamMember[];
}

export interface RankedTeam extends TeamSquad {
  rank: number;
  previousRank?: number;
  teamScore: number; // 0 - 100
  totalIntakeMl: number;
  totalGoalMl: number;
  activeMembersCount: number;
}

export interface DailyHistoryEntry {
  day: string; // Mon, Tue...
  date: string; // YYYY-MM-DD
  intakeMl: number;
  goalMl: number;
  teamAvgMl: number;
  caffeineCount: number;
}

export interface CampusStation {
  id: string;
  name: string;
  building: string;
  floor: string;
  lat: number;
  lng: number;
  status: 'operational' | 'maintenance' | 'busy';
  waterQuality: string;
  availability: string;
  temperature: 'Chilled' | 'Ambient' | 'Filtered';
  isSampleDemo: true;
}

export interface ReminderSettings {
  enabled: boolean;
  startHour: number; // 0-23
  endHour: number; // 0-23
  intervalMinutes: number;
  lastRemindedAt?: string;
}

export type PlantStageId = 'seed' | 'sprout' | 'growing' | 'healthy' | 'blooming';

export interface PlantStatus {
  stage: PlantStageId;
  stageLabel: string;
  stageIndex: number; // 1..5
  isWilted: boolean;
  healthPercent: number;
  message: string;
  nextMilestoneText: string;
}

export interface AppState {
  isAuthenticated: boolean;
  theme: ThemeMode;
  user: UserProfile;
  waterLogs: WaterLog[];
  caffeineLogs: CaffeineLog[];
  teams: TeamSquad[];
  history: DailyHistoryEntry[];
  reminders: ReminderSettings;
  previousUserTeamRank: number | null;
}
