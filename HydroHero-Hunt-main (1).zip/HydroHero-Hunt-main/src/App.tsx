import React, { useEffect, useMemo, useRef, useState } from 'react';
import { CheckCircle2, Trophy } from 'lucide-react';
import type {
  ActivityLevel,
  AppState,
  AppView,
  CaffeineLog,
  GenderOption,
  ReminderSettings,
  TeamSquad,
  WaterLog,
} from './types/hydration';
import {
  calculateAnalyticsSummary,
  calculateCaffeineOffset,
  calculateDailyTarget,
  calculateEffectiveTarget,
  isWithinReminderHours,
  rankTeams,
} from './utils/hydrationMath';
import { loadAppState, resetAppState, saveAppState } from './utils/storage';
import { LandingPage } from './components/LandingPage';
import { AuthPage } from './components/AuthPage';
import { OnboardingPage } from './components/OnboardingPage';
import { SidebarLayout } from './components/SidebarLayout';
import { DashboardPage } from './components/DashboardPage';
import { SquadsPage } from './components/SquadsPage';
import { LeaderboardPage } from './components/LeaderboardPage';
import { AnalyticsPage } from './components/AnalyticsPage';
import { PlantPage } from './components/PlantPage';
import { CampusMapPage } from './components/CampusMapPage';
import { ProfileSettingsPage } from './components/ProfileSettingsPage';

function syncUserIntoTeams(
  teams: TeamSquad[],
  userId: string,
  userName: string,
  userTeamId: string,
  userIntakeMl: number,
  userEffectiveGoalMl: number,
  streakDays: number,
): TeamSquad[] {
  const initials = userName
    .split(' ')
    .filter(Boolean)
    .map((part) => part[0])
    .join('')
    .slice(0, 2)
    .toUpperCase() || 'HH';

  return teams.map((team) => {
    const filtered = team.members.filter((m) => !m.isCurrentUser && m.id !== userId);
    if (team.id !== userTeamId) {
      return { ...team, members: filtered };
    }
    return {
      ...team,
      members: [
        {
          id: userId,
          name: userName,
          role: 'You',
          avatarInitials: initials,
          avatarColor: '#0284c7',
          intakeMl: userIntakeMl,
          goalMl: userEffectiveGoalMl,
          streakDays,
          isCurrentUser: true,
        },
        ...filtered,
      ],
    };
  });
}

export default function App() {
  const [state, setState] = useState<AppState>(() => loadAppState());
  const [activeView, setActiveView] = useState<AppView>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      if (params.get('autostart') === '1' || params.get('quicklog')) {
        return 'dashboard';
      }
    }
    return state.isAuthenticated ? 'dashboard' : 'landing';
  });

  const [pendingAuthCreds, setPendingAuthCreds] = useState<{
    name: string;
    email: string;
  }>({ name: '', email: '' });

  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [overtakeBanner, setOvertakeBanner] = useState<string | null>(null);
  const quicklogHandledRef = useRef(false);

  // Sync dark class on <html>
  useEffect(() => {
    if (typeof document !== 'undefined') {
      document.documentElement.classList.toggle('dark', state.theme === 'dark');
    }
  }, [state.theme]);

  // Persist app state cleanly
  useEffect(() => {
    saveAppState(state);
  }, [state]);

  // Derived daily hydration metrics
  const todayIntakeMl = useMemo(
    () => state.waterLogs.reduce((sum, entry) => sum + entry.amountMl, 0),
    [state.waterLogs],
  );
  const caffeineOffsetMl = useMemo(
    () => calculateCaffeineOffset(state.caffeineLogs.length),
    [state.caffeineLogs.length],
  );
  const effectiveGoalMl = useMemo(
    () => calculateEffectiveTarget(state.user.baseGoalMl, state.caffeineLogs.length),
    [state.user.baseGoalMl, state.caffeineLogs.length],
  );

  // Sync user's latest intake and goal into their active team and rank squads
  const syncedTeams = useMemo(
    () =>
      syncUserIntoTeams(
        state.teams,
        state.user.id,
        state.user.name,
        state.user.teamId,
        todayIntakeMl,
        effectiveGoalMl,
        state.user.streakDays,
      ),
    [state.teams, state.user, todayIntakeMl, effectiveGoalMl],
  );

  const prevRankMapRef = useRef<Record<string, number>>({});
  const rankedTeams = useMemo(
    () => rankTeams(syncedTeams, prevRankMapRef.current),
    [syncedTeams],
  );

  const userTeam = rankedTeams.find((t) => t.id === state.user.teamId);

  const analyticsSummary = useMemo(
    () => calculateAnalyticsSummary(state.history, todayIntakeMl, effectiveGoalMl),
    [state.history, todayIntakeMl, effectiveGoalMl],
  );

  const showToast = (msg: string) => {
    setToastMessage(msg);
    window.setTimeout(() => {
      setToastMessage((cur) => (cur === msg ? null : cur));
    }, 3400);
  };

  // Handle ?autostart=1 and ?quicklog=500 on first mount
  useEffect(() => {
    if (typeof window === 'undefined' || quicklogHandledRef.current) return;
    quicklogHandledRef.current = true;
    const params = new URLSearchParams(window.location.search);
    const autostart = params.get('autostart') === '1';
    const quicklogAmt = Number(params.get('quicklog'));

    if (autostart || (Number.isFinite(quicklogAmt) && quicklogAmt > 0)) {
      setState((prev) => {
        const nextLogs =
          Number.isFinite(quicklogAmt) && quicklogAmt > 0
            ? [
                ...prev.waterLogs,
                {
                  id: `qr-${Date.now()}`,
                  amountMl: Math.round(quicklogAmt),
                  label: `QR Bottle Quick-Log`,
                  timestamp: new Date().toISOString(),
                  source: 'qr' as const,
                },
              ]
            : prev.waterLogs;
        return {
          ...prev,
          isAuthenticated: true,
          waterLogs: nextLogs,
        };
      });
      setActiveView('dashboard');
      if (Number.isFinite(quicklogAmt) && quicklogAmt > 0) {
        showToast(`QR bottle scanned! +${Math.round(quicklogAmt)}ml logged.`);
      }
      // Clean URL query without reload
      window.history.replaceState({}, '', window.location.pathname);
    }
  }, []);

  // Hourly hydration reminder scheduler (strictly respects permission + daytime hours)
  useEffect(() => {
    if (!state.reminders.enabled) return;
    if (typeof window === 'undefined' || !('Notification' in window)) return;
    if (window.Notification.permission !== 'granted') return;

    const intervalMs = Math.max(15, state.reminders.intervalMinutes) * 60 * 1000;
    const timer = window.setInterval(() => {
      const hour = new Date().getHours();
      if (isWithinReminderHours(hour, state.reminders.startHour, state.reminders.endHour)) {
        new window.Notification('SipStreak Hydration Reminder', {
          body: `Stay on pace for your ${effectiveGoalMl}ml goal today!`,
        });
      }
    }, intervalMs);

    return () => window.clearInterval(intervalMs);
  }, [state.reminders, effectiveGoalMl]);

  const checkForRankOvertake = (nextTeams: TeamSquad[], userTeamId: string) => {
    const beforeRanks: Record<string, number> = {};
    rankedTeams.forEach((t) => {
      beforeRanks[t.id] = t.rank;
    });
    prevRankMapRef.current = beforeRanks;

    const nextRanked = rankTeams(nextTeams, beforeRanks);
    const oldRank = beforeRanks[userTeamId];
    const nextUserTeam = nextRanked.find((t) => t.id === userTeamId);

    if (oldRank && nextUserTeam && nextUserTeam.rank < oldRank) {
      const passedTeam = rankedTeams.find((t) => t.rank === nextUserTeam.rank);
      const bannerText = passedTeam
        ? `${nextUserTeam.name} just overtook ${passedTeam.name} to claim Rank #${nextUserTeam.rank}!`
        : `${nextUserTeam.name} climbed to Rank #${nextUserTeam.rank}!`;
      setOvertakeBanner(bannerText);
      showToast(bannerText);
    }
  };

  const handleLogWater = (
    amountMl: number,
    label: string,
    source: WaterLog['source'] = 'custom',
  ) => {
    const newEntry: WaterLog = {
      id: `w-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      amountMl,
      label,
      timestamp: new Date().toISOString(),
      source,
    };

    const nextIntake = todayIntakeMl + amountMl;
    const nextTeams = syncUserIntoTeams(
      state.teams,
      state.user.id,
      state.user.name,
      state.user.teamId,
      nextIntake,
      effectiveGoalMl,
      state.user.streakDays,
    );

    checkForRankOvertake(nextTeams, state.user.teamId);

    setState((prev) => ({
      ...prev,
      waterLogs: [...prev.waterLogs, newEntry],
      teams: nextTeams,
    }));

    showToast(`Logged +${amountMl}ml (${label})`);
  };

  const handleDeleteWaterLog = (id: string) => {
    const target = state.waterLogs.find((w) => w.id === id);
    if (!target) return;
    const nextLogs = state.waterLogs.filter((w) => w.id !== id);
    const nextIntake = nextLogs.reduce((s, l) => s + l.amountMl, 0);
    const nextTeams = syncUserIntoTeams(
      state.teams,
      state.user.id,
      state.user.name,
      state.user.teamId,
      nextIntake,
      effectiveGoalMl,
      state.user.streakDays,
    );
    setState((prev) => ({
      ...prev,
      waterLogs: nextLogs,
      teams: nextTeams,
    }));
    showToast(`Removed ${target.label} (-${target.amountMl}ml)`);
  };

  const handleLogCaffeine = (drinkType: CaffeineLog['drinkType'], label: string) => {
    const newEntry: CaffeineLog = {
      id: `c-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      drinkType,
      label,
      offsetMl: 200,
      timestamp: new Date().toISOString(),
    };
    const nextEffective = calculateEffectiveTarget(
      state.user.baseGoalMl,
      state.caffeineLogs.length + 1,
    );
    const nextTeams = syncUserIntoTeams(
      state.teams,
      state.user.id,
      state.user.name,
      state.user.teamId,
      todayIntakeMl,
      nextEffective,
      state.user.streakDays,
    );
    setState((prev) => ({
      ...prev,
      caffeineLogs: [...prev.caffeineLogs, newEntry],
      teams: nextTeams,
    }));
    showToast(`${label} logged (+200ml compensatory water added to target)`);
  };

  const handleDeleteCaffeineLog = (id: string) => {
    const nextCaffeine = state.caffeineLogs.filter((c) => c.id !== id);
    const nextEffective = calculateEffectiveTarget(state.user.baseGoalMl, nextCaffeine.length);
    const nextTeams = syncUserIntoTeams(
      state.teams,
      state.user.id,
      state.user.name,
      state.user.teamId,
      todayIntakeMl,
      nextEffective,
      state.user.streakDays,
    );
    setState((prev) => ({
      ...prev,
      caffeineLogs: nextCaffeine,
      teams: nextTeams,
    }));
    showToast('Removed caffeine log (-200ml offset)');
  };

  const handleJoinTeamById = (teamId: string): { ok: boolean; message: string } => {
    const target = state.teams.find((t) => t.id === teamId);
    if (!target) return { ok: false, message: 'Squad not found.' };

    const withoutUserCount = target.members.filter(
      (m) => !m.isCurrentUser && m.id !== state.user.id,
    ).length;
    if (withoutUserCount >= target.maxMembers) {
      return {
        ok: false,
        message: `${target.name} is already at max capacity (${target.maxMembers} members).`,
      };
    }

    const nextTeams = syncUserIntoTeams(
      state.teams,
      state.user.id,
      state.user.name,
      target.id,
      todayIntakeMl,
      effectiveGoalMl,
      state.user.streakDays,
    );

    setState((prev) => ({
      ...prev,
      user: { ...prev.user, teamId: target.id },
      teams: nextTeams,
    }));
    return { ok: true, message: `Joined ${target.name}!` };
  };

  const handleJoinTeamByCode = (code: string): { ok: boolean; message: string } => {
    const target = state.teams.find((t) => t.inviteCode.toUpperCase() === code.toUpperCase());
    if (!target) {
      return { ok: false, message: `No squad found with invite code "${code}".` };
    }
    return handleJoinTeamById(target.id);
  };

  const handleCreateSquad = (
    name: string,
    description: string,
    maxMembers: number,
  ): { ok: boolean; message: string } => {
    const code = `${name.replace(/[^A-Za-z0-9]/g, '').slice(0, 4).toUpperCase() || 'HYDRO'}${Math.floor(10 + Math.random() * 89)}`;
    const newTeamId = `team-${Date.now()}`;
    const newSquad: TeamSquad = {
      id: newTeamId,
      name,
      inviteCode: code,
      description: description || 'Collaborative SipStreak hydration squad.',
      maxMembers,
      members: [],
    };
    const nextTeams = syncUserIntoTeams(
      [...state.teams, newSquad],
      state.user.id,
      state.user.name,
      newTeamId,
      todayIntakeMl,
      effectiveGoalMl,
      state.user.streakDays,
    );
    setState((prev) => ({
      ...prev,
      user: { ...prev.user, teamId: newTeamId },
      teams: nextTeams,
    }));
    return { ok: true, message: `Created "${name}" (Invite code: ${code})` };
  };

  const handleCompleteOnboarding = (payload: {
    name: string;
    email: string;
    age: number;
    weightKg: number;
    gender: GenderOption;
    activityLevel: ActivityLevel;
    teamAction: { type: 'join'; teamId: string } | { type: 'create'; squadName: string };
  }) => {
    const newGoalMl = calculateDailyTarget(payload.weightKg);
    let targetTeamId = state.user.teamId;
    let baseTeams = state.teams;

    if (payload.teamAction.type === 'create') {
      const code = `${payload.teamAction.squadName.replace(/[^A-Za-z0-9]/g, '').slice(0, 4).toUpperCase() || 'SQUAD'}26`;
      targetTeamId = `team-${Date.now()}`;
      baseTeams = [
        ...state.teams,
        {
          id: targetTeamId,
          name: payload.teamAction.squadName,
          inviteCode: code,
          description: 'New custom squad launched during onboarding.',
          maxMembers: 6,
          members: [],
        },
      ];
    } else {
      targetTeamId = payload.teamAction.teamId;
    }

    const updatedUser = {
      ...state.user,
      name: payload.name,
      email: payload.email,
      age: payload.age,
      weightKg: payload.weightKg,
      gender: payload.gender,
      activityLevel: payload.activityLevel,
      baseGoalMl: newGoalMl,
      teamId: targetTeamId,
      onboarded: true,
    };

    const nextEffective = calculateEffectiveTarget(newGoalMl, state.caffeineLogs.length);
    const nextTeams = syncUserIntoTeams(
      baseTeams,
      updatedUser.id,
      updatedUser.name,
      updatedUser.teamId,
      todayIntakeMl,
      nextEffective,
      updatedUser.streakDays,
    );

    setState((prev) => ({
      ...prev,
      isAuthenticated: true,
      user: updatedUser,
      teams: nextTeams,
    }));
    setActiveView('dashboard');
    showToast(`Welcome ${payload.name}! Daily target calibrated to ${newGoalMl} ml.`);
  };

  const handleToggleTheme = () => {
    setState((prev) => ({
      ...prev,
      theme: prev.theme === 'dark' ? 'light' : 'dark',
    }));
  };

  const handleUpdateProfile = (updates: {
    name: string;
    weightKg: number;
    activityLevel: ActivityLevel;
  }) => {
    const newBaseGoal = calculateDailyTarget(updates.weightKg);
    const nextEffective = calculateEffectiveTarget(newBaseGoal, state.caffeineLogs.length);
    const nextUser = {
      ...state.user,
      name: updates.name,
      weightKg: updates.weightKg,
      activityLevel: updates.activityLevel,
      baseGoalMl: newBaseGoal,
    };
    const nextTeams = syncUserIntoTeams(
      state.teams,
      nextUser.id,
      nextUser.name,
      nextUser.teamId,
      todayIntakeMl,
      nextEffective,
      nextUser.streakDays,
    );
    setState((prev) => ({
      ...prev,
      user: nextUser,
      teams: nextTeams,
    }));
  };

  const handleUpdateReminders = (next: ReminderSettings) => {
    setState((prev) => ({ ...prev, reminders: next }));
  };

  const handleResetDemoData = () => {
    const fresh = resetAppState();
    fresh.isAuthenticated = true;
    setState(fresh);
    setOvertakeBanner(null);
    showToast('Demo state restored to defaults.');
  };

  // Route public screens (Landing, Auth, Onboarding)
  if (activeView === 'landing') {
    return (
      <LandingPage
        onStartJourney={() => setActiveView('auth')}
        onQuickDemo={() => {
          setState((prev) => ({ ...prev, isAuthenticated: true }));
          setActiveView('dashboard');
        }}
        rankedTeams={rankedTeams}
        theme={state.theme}
        onToggleTheme={handleToggleTheme}
      />
    );
  }

  if (activeView === 'auth') {
    return (
      <AuthPage
        onBackToLanding={() => setActiveView('landing')}
        onSignUpStart={(creds) => {
          setPendingAuthCreds({ name: creds.name, email: creds.email });
          setActiveView('onboarding');
        }}
        onDemoLogin={() => {
          setState((prev) => ({ ...prev, isAuthenticated: true }));
          setActiveView('dashboard');
          showToast(`Signed in as ${state.user.name}`);
        }}
        onLoginExisting={(email) => {
          setState((prev) => ({
            ...prev,
            isAuthenticated: true,
            user: { ...prev.user, email },
          }));
          setActiveView('dashboard');
          showToast(`Signed in as ${email}`);
        }}
      />
    );
  }

  if (activeView === 'onboarding') {
    return (
      <OnboardingPage
        initialName={pendingAuthCreds.name}
        initialEmail={pendingAuthCreds.email}
        teams={state.teams}
        onCompleteOnboarding={handleCompleteOnboarding}
      />
    );
  }

  return (
    <>
      <SidebarLayout
        activeView={activeView}
        onNavigate={setActiveView}
        user={state.user}
        theme={state.theme}
        onToggleTheme={handleToggleTheme}
        onLogout={() => {
          setState((prev) => ({ ...prev, isAuthenticated: false }));
          setActiveView('landing');
        }}
        effectiveGoalMl={effectiveGoalMl}
        todayIntakeMl={todayIntakeMl}
      >
        {overtakeBanner && activeView !== 'leaderboard' && (
          <div
            role="status"
            className="mb-5 rounded-2xl bg-gradient-to-r from-sky-600 to-cyan-500 text-white px-4 py-3 flex items-center justify-between gap-4 shadow-sm"
          >
            <div className="flex items-center gap-2.5 text-sm font-semibold">
              <Trophy className="w-4 h-4 shrink-0" />
              <span>{overtakeBanner}</span>
            </div>
            <div className="flex items-center gap-3 shrink-0">
              <button
                type="button"
                onClick={() => setActiveView('leaderboard')}
                className="text-xs font-semibold underline underline-offset-4"
              >
                View Podium
              </button>
              <button
                type="button"
                onClick={() => setOvertakeBanner(null)}
                className="text-xs opacity-85 hover:opacity-100"
              >
                Dismiss
              </button>
            </div>
          </div>
        )}

        {activeView === 'dashboard' && (
          <DashboardPage
            user={state.user}
            waterLogs={state.waterLogs}
            caffeineLogs={state.caffeineLogs}
            todayIntakeMl={todayIntakeMl}
            caffeineOffsetMl={caffeineOffsetMl}
            effectiveGoalMl={effectiveGoalMl}
            weeklyAverageMl={analyticsSummary.weeklyAverageMl}
            userTeam={userTeam}
            onLogWater={handleLogWater}
            onDeleteWaterLog={handleDeleteWaterLog}
            onLogCaffeine={handleLogCaffeine}
            onDeleteCaffeineLog={handleDeleteCaffeineLog}
            onNavigate={setActiveView}
          />
        )}

        {activeView === 'squads' && (
          <SquadsPage
            user={state.user}
            rankedTeams={rankedTeams}
            onJoinTeamByCode={handleJoinTeamByCode}
            onJoinTeamById={handleJoinTeamById}
            onCreateSquad={handleCreateSquad}
          />
        )}

        {activeView === 'leaderboard' && (
          <LeaderboardPage
            rankedTeams={rankedTeams}
            user={state.user}
            overtakeBanner={overtakeBanner}
            onDismissBanner={() => setOvertakeBanner(null)}
          />
        )}

        {activeView === 'analytics' && (
          <AnalyticsPage
            history={state.history}
            todayIntakeMl={todayIntakeMl}
            effectiveGoalMl={effectiveGoalMl}
            user={state.user}
          />
        )}

        {activeView === 'plant' && (
          <PlantPage
            todayIntakeMl={todayIntakeMl}
            effectiveGoalMl={effectiveGoalMl}
            user={state.user}
            onQuickWater={(amt, lbl) => handleLogWater(amt, lbl, 'cup')}
          />
        )}

        {activeView === 'map' && <CampusMapPage />}

        {activeView === 'profile' && (
          <ProfileSettingsPage
            user={state.user}
            theme={state.theme}
            reminders={state.reminders}
            onToggleTheme={handleToggleTheme}
            onUpdateProfile={handleUpdateProfile}
            onUpdateReminders={handleUpdateReminders}
            onSimulateQrScan={() => {
              handleLogWater(500, 'QR Bottle Scan', 'qr');
              setActiveView('dashboard');
            }}
            onResetDemoData={handleResetDemoData}
          />
        )}
      </SidebarLayout>

      {/* Success Notification Toast */}
      {toastMessage && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-20 lg:bottom-6 right-4 sm:right-6 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl bg-slate-900 dark:bg-cyan-500 text-white dark:text-slate-950 text-sm font-semibold shadow-lg border border-slate-700 dark:border-cyan-300"
        >
          <CheckCircle2 className="w-4 h-4 text-cyan-400 dark:text-slate-950 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}
    </>
  );
}
